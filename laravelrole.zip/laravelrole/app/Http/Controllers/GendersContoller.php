<?php

namespace App\Http\Controllers;

use App\Models\Gender;
use Illuminate\Http\Request;

class GendersContoller extends Controller
{
    public function dropDownShow()
    {
        // $genders = Gender::all();
        // return view('backend.pages.users.index', compact('genders'));

        // $data['genders']= Gender::all();
        // return view('backend.pages.roles.index',$data);

        //return 'ok';

        $genders = Gender::all();
        return view('backend.pages.users.create', compact('genders'));

    }
}
