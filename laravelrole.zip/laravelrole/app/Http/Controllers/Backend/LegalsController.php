<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Legal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class LegalsController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('manage.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }
        $legals = Legal::all();
        return view('backend.pages.legals.index', compact('legals'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }
        $legals = Legal::all();
        return view('backend.pages.legals.create', compact('legals'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }
        // Create New User
        $legal = new Legal();

        $legal->legalname = $request->legalname;
        $legal->legalid = $request->legalid;

        // $user->password = Hash::make($request->password);
        $legal->save();

        // if ($request->roles) {
        //     $user->assignRole($request->roles);
        // }

        session()->flash('success', 'Legal has been created !!');
        return redirect()->route('legals.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }
        $legal = Legal::find($id);
        $legals = Legal::all();
        return view('backend.pages.legals.edit', compact('legal', 'legals'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }
        // Create New User
        $legal = Legal::find($id);

        $legal->legalname = $request->legalname;
        $legal->legalid = $request->legalid;

        $legal->save();


        session()->flash('success', 'Legal has been updated !!');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if (is_null($this->user) || !$this->user->can('manage.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }
        $legal = Legal::find($id);
        if (!is_null($legal)) {
            $legal->delete();
        }

        session()->flash('success', 'Legal has been deleted !!');
        return back();
    }
}
