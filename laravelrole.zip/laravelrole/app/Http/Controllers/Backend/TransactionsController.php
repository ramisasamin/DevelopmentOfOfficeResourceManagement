<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Inventoryorg;
use App\Models\Item;
use Illuminate\Support\Facades\Auth;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TransactionsController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('invtransaction.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $transactions = Transaction::all();
        return view('backend.pages.transactions.index', compact('transactions'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('invtransaction.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        $transactions = Transaction::all();
        $items = Item::all();
        $inventoryorgs = Inventoryorg::all();

        return view('backend.pages.transactions.create', compact('transactions', 'items', 'inventoryorgs'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        if (is_null($this->user) || !$this->user->can('invtransaction.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        // Create New User
        $transaction = new Transaction();

        $transaction->transdate = $request->transdate;
        $transaction->transtype = $request->transtype;
        $transaction->itemcode = $request->itemcode;
        $transaction->quantity = $request->quantity;
        $transaction->invcode = $request->invcode;
        $transaction->invname = $request->invname;

        // $user->password = Hash::make($request->password);
        $transaction->save();

        // if ($request->roles) {
        //     $user->assignRole($request->roles);
        // }

        session()->flash('success', 'Transaction has been created !!');
        return redirect()->route('transactions.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (is_null($this->user) || !$this->user->can('invtransaction.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        $transaction = Transaction::find($id);
        $transactions = Transaction::all();
        $items = Item::all();
        $inventoryorgs = Inventoryorg::all();

        return view('backend.pages.transactions.edit', compact('transaction', 'transactions', 'items', 'inventoryorgs'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (is_null($this->user) || !$this->user->can('invtransaction.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        // Create New User
        $transaction = Transaction::find($id);

        $transaction->transdate = $request->transdate;
        $transaction->transtype = $request->transtype;
        $transaction->itemcode = $request->itemcode;
        $transaction->quantity = $request->quantity;
        $transaction->invcode = $request->invcode;
        $transaction->invname = $request->invname;

        $transaction->save();


        session()->flash('success', 'Transaction has been updated !!');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if (is_null($this->user) || !$this->user->can('invtransaction.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }

        $transaction = Transaction::find($id);
        if (!is_null($transaction)) {
            $transaction->delete();
        }

        session()->flash('success', 'Transaction has been deleted !!');
        return back();
    }

    public function getInv(Request $request) {
        $item = DB::table('inventoryorgs')->where('invcode', $request->invcode)->pluck('invname')->first();
        return $item;
    }

    public function getItem(Request $request) {
        $item = DB::table('items')->where('itemcode', $request->itemcode)->pluck('itemdes')->first();
        return $item;
    }
}
