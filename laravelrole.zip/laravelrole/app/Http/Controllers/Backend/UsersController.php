<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\Gender;
use App\Models\Grade;
use App\Models\Job;
use App\Models\Location;
use App\Models\Marital;
use App\Models\Nationality;
use App\Models\Persontype;
use App\Models\Position;
use App\Models\Status;
use App\Models\Title;
use App\Models\Unit;

class UsersController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('employee.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $users = User::all();
        $genders = Gender::all();
        $titles = Title::all();
        $persontypes = Persontype::all();
        $maritals = Marital::all();
        $nationalities = Nationality::all();
        $units = Unit::all();
        $jobs = Job::all();
        $grades = Grade::all();
        $locations = Location::all();
        $categories = Category::all();
        $positions = Position::all();
        $statuses = Status::all();
        return view('backend.pages.users.index', compact('users', 'genders', 'titles', 'persontypes', 'maritals', 'nationalities', 'units', 'jobs', 'grades', 'locations', 'categories', 'positions', 'statuses'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('employee.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        // $roles  = Role::all();
        // return view('backend.pages.users.create', compact('roles'));
        $genders = Gender::all();
        $titles = Title::all();
        $persontypes = Persontype::all();
        $maritals = Marital::all();
        $nationalities = Nationality::all();
        $units = Unit::all();
        $jobs = Job::all();
        $grades = Grade::all();
        $locations = Location::all();
        $categories = Category::all();
        $positions = Position::all();
        $statuses = Status::all();
        return view('backend.pages.users.create' , compact('genders', 'titles', 'persontypes', 'maritals', 'nationalities', 'units', 'jobs', 'grades', 'locations', 'categories', 'positions', 'statuses'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (is_null($this->user) || !$this->user->can('employee.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        // return $request->all();
        $image = $request->file('image');

        // Create New User
        $user = new User();

        $user->titlename = $request->titlename;
        $user->name = $request->name;
        $user->namel = $request->namel;
        $user->email = $request->email;
        $user->fname = $request->fname;
        $user->fno = $request->fno;
        $user->mname = $request->mname;
        $user->mno = $request->mno;
        $user->gendername = $request->gendername;
        $user->systemtype = $request->systemtype;
        $user->eid = $request->eid;
        $user->nid = $request->nid;
        $user->start = $request->start;
        $user->end = $request->end;
        $user->bd = $request->bd;
        $user->place = $request->place;
        $user->maritalstatus = $request->maritalstatus;
        $user->nationalityname = $request->nationalityname;

        if ($request->hasFile('image'))
        {
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension();
            $filename = time().'.'.$extension;
            $file->move('uploads/users/', $filename);
            $user->image = $filename;
        }

        $user->office = $request->office;
        $user->address = $request->address;
        $user->ono = $request->ono;
        $user->pno = $request->pno;
        $user->shortname = $request->shortname;
        $user->statusassign = $request->statusassign;
        $user->jobname = $request->jobname;
        $user->sscale = $request->sscale;
        $user->gradecode = $request->gradecode;
        $user->locationcode = $request->locationcode;
        $user->supname = $request->supname;
        $user->supno = $request->supno;
        $user->assignno = $request->assignno;
        $user->period = $request->period;
        $user->categoryname = $request->categoryname;
        $user->periodend = $request->periodend;
        $user->grp = $request->grp;
        $user->notice = $request->notice;
        $user->positionname = $request->positionname;
        $user->whour = $request->whour;
        $user->shr = $request->shr;
        $user->stime = $request->stime;
        $user->etime = $request->etime;
        $user->checkbox = $request->checkbox;
        $user->datestart = $request->datestart;
        $user->dateend= $request->dateend;


        $user->save();

        // if ($request->genders)
        // {
        //     $user->assignGender($request->genders);
        // }


        session()->flash('success', 'User has been created !!');
        return redirect()->route('users.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::find($id);
        $roles  = Role::all();
        $genders = Gender::all();
        $titles = Title::all();
        $persontypes = Persontype::all();
        $maritals = Marital::all();
        $nationalities = Nationality::all();
        $units = Unit::all();
        $jobs = Job::all();
        $grades = Grade::all();
        $locations = Location::all();
        $categories = Category::all();
        $positions = Position::all();
        $statuses = Status::all();
        return view('backend.pages.users.show', compact('user', 'roles', 'genders', 'titles', 'persontypes', 'maritals', 'nationalities', 'units', 'jobs', 'grades', 'locations', 'categories', 'positions', 'statuses'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (is_null($this->user) || !$this->user->can('employee.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        $user = User::find($id);
        $roles  = Role::all();
        $genders = Gender::all();
        $titles = Title::all();
        $persontypes = Persontype::all();
        $maritals = Marital::all();
        $nationalities = Nationality::all();
        $units = Unit::all();
        $jobs = Job::all();
        $grades = Grade::all();
        $locations = Location::all();
        $categories = Category::all();
        $positions = Position::all();
        $statuses = Status::all();
        return view('backend.pages.users.edit', compact('user', 'roles', 'genders', 'titles', 'persontypes', 'maritals', 'nationalities', 'units', 'jobs', 'grades', 'locations', 'categories', 'positions', 'statuses'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (is_null($this->user) || !$this->user->can('employee.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        // Create New User
        $user = User::find($id);

        $user->titlename = $request->titlename;
        $user->name = $request->name;
        $user->namel = $request->namel;
        $user->email = $request->email;
        $user->fname = $request->fname;
        $user->fno = $request->fno;
        $user->mname = $request->mname;
        $user->mno = $request->mno;
        $user->gendername = $request->gendername;
        $user->systemtype = $request->systemtype;
        $user->eid = $request->eid;
        $user->nid = $request->nid;
        $user->start = $request->start;
        $user->end = $request->end;
        $user->bd = $request->bd;
        $user->place = $request->place;
        $user->maritalstatus = $request->maritalstatus;
        $user->nationalityname = $request->nationalityname;

        if ($request->hasfile('iamge'))
        {
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension();
            $filename = time().'.'.$extension;
            $file->move('uploads/users/', $filename);
            $user->image = $filename;
        }
        else
        {
            return $request;
            $user->image = '';
        }

        $user->office = $request->office;
        $user->address = $request->address;
        $user->ono = $request->ono;
        $user->pno = $request->pno;
        $user->shortname = $request->shortname;
        $user->statusassign = $request->statusassign;
        $user->jobname = $request->jobname;
        $user->sscale = $request->sscale;
        $user->gradecode = $request->gradecode;
        $user->locationcode = $request->locationcode;
        $user->supname = $request->supname;
        $user->supno = $request->supno;
        $user->assignno = $request->assignno;
        $user->period = $request->period;
        $user->categoryname = $request->categoryname;
        $user->periodend = $request->periodend;
        $user->grp = $request->grp;
        $user->notice = $request->notice;
        $user->positionname = $request->positionname;
        $user->whour = $request->whour;
        $user->shr = $request->shr;
        $user->stime = $request->stime;
        $user->etime = $request->etime;
        $user->checkbox = $request->checkbox;
        $user->datestart = $request->datestart;
        $user->dateend= $request->dateend;


        $user->save();

        // $user->roles()->detach();
        // if ($request->roles) {
        //     $user->assignRole($request->roles);
        // }

        session()->flash('success', 'User has been updated !!');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if (is_null($this->user) || !$this->user->can('employee.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }

        $user = User::find($id);
        if (!is_null($user)) {
            $user->delete();
        }

        session()->flash('success', 'User has been deleted !!');
        return back();
    }
}
