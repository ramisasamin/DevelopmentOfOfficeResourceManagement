<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Ilocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class IlocationsController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('invlocation.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }
        $ilocations = Ilocation::all();
        return view('backend.pages.ilocations.index', compact('ilocations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('invlocation.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        $ilocations = Ilocation::all();
        return view('backend.pages.ilocations.create', compact('ilocations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        if (is_null($this->user) || !$this->user->can('invlocation.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        // Create New User
        $ilocation = new Ilocation();

        $ilocation->lname = $request->lname;
        $ilocation->ldescription = $request->ldescription;
        $ilocation->linactivedate = $request->linactivedate;
        $ilocation->ladd = $request->ladd;
        $ilocation->lcity = $request->lcity;
        $ilocation->lregion = $request->lregion;
        $ilocation->lcountry = $request->lcountry;
        $ilocation->lpostalcode = $request->lpostalcode;
        $ilocation->ltelephone = $request->ltelephone;
        $ilocation->lship2location = $request->lship2location;
        $ilocation->lship2site = $request->lship2site;
        $ilocation->lbill2ship = $request->lbill2ship;

        // $user->password = Hash::make($request->password);
        $ilocation->save();

        // if ($request->roles) {
        //     $user->assignRole($request->roles);
        // }

        session()->flash('success', 'Location has been created !!');
        return redirect()->route('ilocations.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (is_null($this->user) || !$this->user->can('invlocation.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }
        $ilocation = Ilocation::find($id);
        $ilocations = Ilocation::all();
        return view('backend.pages.ilocations.edit', compact('ilocation', 'ilocations'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        if (is_null($this->user) || !$this->user->can('invlocation.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        // Create New User
        $ilocation = Ilocation::find($id);

        $ilocation->lname = $request->lname;
        $ilocation->ldescription = $request->ldescription;
        $ilocation->linactivedate = $request->linactivedate;
        $ilocation->ladd = $request->ladd;
        $ilocation->lcity = $request->lcity;
        $ilocation->lregion = $request->lregion;
        $ilocation->lcountry = $request->lcountry;
        $ilocation->lpostalcode = $request->lpostalcode;
        $ilocation->ltelephone = $request->ltelephone;
        $ilocation->lship2location = $request->lship2location;
        $ilocation->lship2site = $request->lship2site;
        $ilocation->lbill2ship = $request->lbill2ship;

        $ilocation->save();


        session()->flash('success', 'Location has been updated !!');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if (is_null($this->user) || !$this->user->can('invlocation.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }

        $ilocation = Ilocation::find($id);
        if (!is_null($ilocation)) {
            $ilocation->delete();
        }

        session()->flash('success', 'Location has been deleted !!');
        return back();
    }
}
