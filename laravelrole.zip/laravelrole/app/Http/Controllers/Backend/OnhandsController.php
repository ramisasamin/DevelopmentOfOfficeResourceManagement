<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Assign;
use App\Models\Inventoryorg;
use App\Models\Item;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OnhandsController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('invonhand.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $inventoryorgs = Inventoryorg::all();
        $items = Item::all();
        $items = DB::table('items')
            ->leftJoin('transactions', 'items.itemcode', '=', 'transactions.itemcode')
            ->select('items.invcode', 'items.itemcode', 'items.itemdes', 'items.measure', 'transactions.quantity')
            ->get();


        return view('backend.pages.onhands.index', compact('inventoryorgs', 'items'));
    }

    public function getInv(Request $request) {
        $item = DB::table('inventoryorgs')->where('invcode', $request->invcode)->pluck('invname')->first();
        return $item;
    }

    public function getItem(Request $request) {
        $item = DB::table('items')->where('itemcode', $request->itemcode)->pluck('itemdes')->first();
        return $item;
    }
    public function find(Request $r){

        $inventoryorgs = Inventoryorg::all();
        $items = Item::where('invcode', '=' , $r['invcode'])->where('itemcode', '=' , $r['itemcode'])->get();
        return view('backend.pages.onhands.index', compact('inventoryorgs', 'items'));
    }
}
