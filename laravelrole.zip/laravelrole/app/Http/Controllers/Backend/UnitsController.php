<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Unit;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class UnitsController extends Controller
{
    public $user;

        public function __construct()
        {
            $this->middleware(function ($request, $next) {
                $this->user = Auth::guard('admin')->user();
                return $next($request);
            });
        }

    public $unit;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('manage.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $units = Unit::all();
        return view('backend.pages.organizations.index', compact('units'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        $units = Unit::all();
        return view('backend.pages.organizations.create', compact('units'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

                // Validation Data
                $request->validate([
                    'unitname' => 'required|max:200',
                    'shortname' => 'required|max:200',
                ]);
        
                // Create New User
                $unit = new Unit();
                    
                $unit->unitname = $request->unitname;
                $unit->shortname = $request->shortname;
                
                // $user->password = Hash::make($request->password);
                $unit->save();
        
                // if ($request->roles) {
                //     $user->assignRole($request->roles);
                // }
        
                session()->flash('success', 'Organization has been created !!');
                return redirect()->route('units.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }
        $unit = Unit::find($id);
        $units = Unit::all();
        return view('backend.pages.organizations.edit', compact('unit','units'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

                // Create New User
                $unit = Unit::find($id);

                // Validation Data
                $request->validate([
                    'unitname' => 'required|max:200',
                    'shortname' => 'required|max:200'. $id,
                    
                ]);
        
        
                $unit->unitname = $request->unitname;
                $unit->shortname = $request->shortname;
                
                $unit->save();

        
                session()->flash('success', 'Organization has been updated !!');
                return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if (is_null($this->user) || !$this->user->can('manage.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }
        
        $unit = Unit::find($id);
        if (!is_null($unit)) {
            $unit->delete();
        }

        session()->flash('success', 'Organization has been deleted !!');
        return back();
    }
}
