<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Ledger;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class LedgersController extends Controller
{

    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        if (is_null($this->user) || !$this->user->can('manage.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }
        
        $ledgers = Ledger::all();
        return view('backend.pages.ledgers.index', compact('ledgers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }
        $ledgers = Ledger::all();
        return view('backend.pages.ledgers.create', compact('ledgers'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }
        // Create New User
        $ledger = new Ledger();

        $ledger->ledgername = $request->ledgername;

        // $user->password = Hash::make($request->password);
        $ledger->save();

        // if ($request->roles) {
        //     $user->assignRole($request->roles);
        // }

        session()->flash('success', 'Ledger has been created !!');
        return redirect()->route('ledgers.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        $ledger = Ledger::find($id);
        $ledgers = Ledger::all();
        return view('backend.pages.ledgers.edit', compact('ledger', 'ledgers'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }
        // Create New User
        $ledger = Ledger::find($id);

        $ledger->ledgername = $request->ledgername;

        $ledger->save();


        session()->flash('success', 'Ledger has been updated !!');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        
        if (is_null($this->user) || !$this->user->can('manage.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }
        $ledger = Ledger::find($id);
        if (!is_null($ledger)) {
            $ledger->delete();
        }

        session()->flash('success', 'Ledger has been deleted !!');
        return back();
    }
}
