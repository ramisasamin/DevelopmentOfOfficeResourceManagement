<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Location;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class LocationsController extends Controller
{
    public $user;

        public function __construct()
        {
            $this->middleware(function ($request, $next) {
                $this->user = Auth::guard('admin')->user();
                return $next($request);
            });
        }

    public $location;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('manage.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $locations = Location::all();
        return view('backend.pages.locations.index', compact('locations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        $locations = Location::all();
        return view('backend.pages.locations.create', compact('locations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }
                // Validation Data
                $request->validate([
                    'locationcode' => 'required|max:200',
                    'description' => 'required|max:200',
                ]);
        
                // Create New User
                $location = new Location();
                    
                $location->locationcode = $request->locationcode;
                $location->description = $request->description;
                
                // $user->password = Hash::make($request->password);
                $location->save();
        
                // if ($request->roles) {
                //     $user->assignRole($request->roles);
                // }
        
                session()->flash('success', 'Location has been created !!');
                return redirect()->route('locations.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }
        $location = Location::find($id);
        $locations = Location::all();
        return view('backend.pages.locations.edit', compact('location','locations'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }
                // Create New User
                $location = Location::find($id);

                // Validation Data
                $request->validate([
                    'locationcode' => 'required|max:200',
                    'description' => 'required|max:200'. $id,
                    
                ]);
        
        
                $location->locationcode = $request->locationcode;
                $location->description = $request->description;
                
                $location->save();

        
                session()->flash('success', 'Location has been updated !!');
                return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if (is_null($this->user) || !$this->user->can('manage.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }
        
        $location = Location::find($id);
        if (!is_null($location)) {
            $location->delete();
        }

        session()->flash('success', 'Location has been deleted !!');
        return back();
    }
}
