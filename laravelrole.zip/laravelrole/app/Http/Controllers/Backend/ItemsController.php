<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Inventoryorg;
use App\Models\Item;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ItemsController extends Controller
{

    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('item.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $items = Item::all();

        return view('backend.pages.items.index', compact('items'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('item.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }
        $items = Item::all();
        $inventoryorgs = Inventoryorg::all();

        return view('backend.pages.items.create', compact('items', 'inventoryorgs'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (is_null($this->user) || !$this->user->can('item.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }
        // Create New User
        $item = new Item();


        $item->invcode = $request->invcode;
        $item->invname = $request->invname;
        $item->itemcode = $request->itemcode;
        $item->itemdes = $request->itemdes;
        $item->measure = $request->measure;
        $item->itemtype = $request->itemtype;
        $item->itemstatus = $request->itemstatus;
        $item->lot = $request->lot;
        $item->makebuy = $request->makebuy;
        $item->minitem = $request->minitem;
        $item->maxitem = $request->maxitem;
        $item->mindays = $request->mindays;
        $item->maxdays = $request->maxdays;
        $item->invitem = $request->invitem;
        $item->stockable = $request->stockable;
        $item->reservable = $request->reservable;
        $item->transactable = $request->transactable;
        $item->purchaseable = $request->purchaseable;
        $item->customerordered = $request->customerordered;
        $item->internalordered = $request->internalordered;
        $item->shippabbleordered = $request->shippabbleordered;
        $item->returnable = $request->returnable;


        // $user->password = Hash::make($request->password);
        $item->save();

        // if ($request->roles) {
        //     $user->assignRole($request->roles);
        // }

        session()->flash('success', 'Item has been created !!');
        return redirect()->route('items.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $item = Item::find($id);
        $items = Item::all();
        $inventoryorgs = Inventoryorg::all();

        return view('backend.pages.items.show', compact('item', 'items', 'inventoryorgs'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (is_null($this->user) || !$this->user->can('item.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        $item = Item::find($id);
        $items = Item::all();
        $inventoryorgs = Inventoryorg::all();

        return view('backend.pages.items.edit', compact('item', 'items', 'inventoryorgs'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (is_null($this->user) || !$this->user->can('item.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        // Create New User
        $item = Item::find($id);


        $item->invcode = $request->invcode;
        $item->invname = $request->invname;
        $item->itemcode = $request->itemcode;
        $item->itemdes = $request->itemdes;
        $item->measure = $request->measure;
        $item->itemtype = $request->itemtype;
        $item->itemstatus = $request->itemstatus;
        $item->lot = $request->lot;
        $item->makebuy = $request->makebuy;
        $item->minitem = $request->minitem;
        $item->maxitem = $request->maxitem;
        $item->mindays = $request->mindays;
        $item->maxdays = $request->maxdays;
        $item->invitem = $request->invitem;
        $item->stockable = $request->stockable;
        $item->reservable = $request->reservable;
        $item->transactable = $request->transactable;
        $item->purchaseable = $request->purchaseable;
        $item->customerordered = $request->customerordered;
        $item->internalordered = $request->internalordered;
        $item->shippabbleordered = $request->shippabbleordered;
        $item->returnable = $request->returnable;

        $item->save();


        session()->flash('success', 'Item has been updated !!');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if (is_null($this->user) || !$this->user->can('item.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }
        $item = Item::find($id);
        if (!is_null($item)) {
            $item->delete();
        }

        session()->flash('success', 'Item has been deleted !!');
        return back();
    }

    public function getInv(Request $request) {
        $item = DB::table('inventoryorgs')->where('invcode', $request->invcode)->pluck('invname')->first();
        return $item;
    }
}
