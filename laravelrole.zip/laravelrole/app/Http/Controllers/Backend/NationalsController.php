<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Nationality;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class NationalsController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        if (is_null($this->user) || !$this->user->can('manage.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $nationalities = Nationality::all();
        return view('backend.pages.nationalities.index', compact('nationalities'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        $nationalities = Nationality::all();
        return view('backend.pages.nationalities.create', compact('nationalities'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        // Validation Data
        $request->validate([
            'nationalityname' => 'required|max:200',
        ]);

        // Create New User
        $nationality = new Nationality();
            
        $nationality->nationalityname = $request->nationalityname;
        
        // $user->password = Hash::make($request->password);
        $nationality->save();

        // if ($request->roles) {
        //     $user->assignRole($request->roles);
        // }

        session()->flash('success', 'Nationality has been created !!');
        return redirect()->route('nationalities.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        $nationality = Nationality::find($id);
        $nationalities = Nationality::all();
        return view('backend.pages.nationalities.edit', compact('nationality', 'nationalities'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        // Create New User
        $nationality = Nationality::find($id);

        // Validation Data
        $request->validate([
        'nationalityname' => 'required|max:200'. $id,
                    
        ]);        
        
        $nationality->nationalityname = $request->nationalityname;
                
        $nationality->save();

        
        session()->flash('success', 'Nationality has been updated !!');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if (is_null($this->user) || !$this->user->can('manage.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }
        
        $nationality = Nationality::find($id);
        if (!is_null($nationality)) {
            $nationality->delete();
        }

        session()->flash('success', 'Nationality has been deleted !!');
        return back();
    }
}
