<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Assign;
use Illuminate\Support\Facades\Auth;
use App\Models\Inventoryorg;
use App\Models\User;
use App\Models\Item;
use App\Models\Receive;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;

class AssignsController extends Controller
{
    public $user;
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('assignitem.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $assigns = Assign::all();
        $assigns = DB::table('assigns')
            ->leftJoin('receives', 'assigns.eid', '=', 'receives.eid')
            ->select('assigns.eid', 'assigns.name', 'assigns.itemcode', 'assigns.itemdes', 'assigns.invcode', 'assigns.invname', 'assigns.assigndate', 'assigns.remarks', 'receives.rdate')
            ->get();
        $inventoryorgs = Inventoryorg::all();
        $users = User::all();
        $items = Item::all();
        $receives = Receive::all();
        return view('backend.pages.assigns.index', compact('assigns', 'inventoryorgs', 'users', 'items', 'receives'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('assignitem.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }


        $assigns = Assign::all();
        $inventoryorgs = Inventoryorg::all();
        $users = User::all();
        $items = Item::all();

        return view('backend.pages.assigns.create', compact('assigns', 'inventoryorgs', 'users', 'items'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        if (is_null($this->user) || !$this->user->can('assignitem.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        $inventoryCode = $request->itemcode;

        $remainingQuantity = Transaction::where('itemcode', $inventoryCode)->first();
        $remain = $remainingQuantity->count('id');
        $assignItem = Assign::where('itemcode', $inventoryCode)->get();
        $assignQuantity = $assignItem->count('id');
        if($remain<=$assignQuantity){
            session()->flash('error', 'cannot assign');
            return redirect()->route('assigns.index');
        }
        $beforeAssign = $remainingQuantity->quantity;
        // $afterAssign;
        $remainingQuantity->decrement('quantity');
        $remainingQuantity->update();


        // Create New Use
        $assign = new Assign();


        $assign->eid = $request->eid;
        $assign->name = $request->name;
        $assign->itemcode = $request->itemcode;
        $assign->itemdes = $request->itemdes;
        $assign->invcode = $request->invcode;
        $assign->invname = $request->invname;
        $assign->assigndate = $request->assigndate;
        $assign->noitem = $request->noitem;
        $assign->remarks = $request->remarks;
        $assign->warranty = $request->warranty;

        // $user->password = Hash::make($request->password);
        $assign->save();

        // if ($request->roles) {
        //     $user->assignRole($request->roles);
        // }

        session()->flash('success', 'Transaction has been created !!');
        return redirect()->route('assigns.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function edit($id)
    // {
    //     if (is_null($this->user) || !$this->user->can('assignitem.edit')) {
    //         abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
    //     }

    //     $assign = Assign::find($id);
    //     $assigns = Assign::all();
    //     $inventoryorgs = Inventoryorg::all();
    //     $users = User::all();
    //     $items = Item::all();

    //     return view('backend.pages.assigns.edit', compact('assign', 'assigns', 'inventoryorgs', 'users', 'items'));
    // }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (is_null($this->user) || !$this->user->can('assignitem.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        // Create New User
        $assign = Assign::find($id);


        $assign->eid = $request->eid;
        $assign->name = $request->name;
        $assign->itemcode = $request->itemcode;
        $assign->itemdes = $request->itemdes;
        $assign->invcode = $request->invcode;
        $assign->invname = $request->invname;
        $assign->assigndate = $request->assigndate;
        $assign->noitem = $request->noitem;
        $assign->remarks = $request->remarks;
        $assign->warranty = $request->warranty;

        $assign->save();


        session()->flash('success', 'Location has been updated !!');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {

        if (is_null($this->user) || !$this->user->can('assignitem.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }

        $assign = Assign::find($id);
        if (!is_null($assign)) {
            $assign->delete();
        }

        session()->flash('success', 'Location has been deleted !!');
        return back();
    }

    public function getEmp(Request $request) {
        $assign = DB::table('users')->where('eid', $request->eid)->pluck('name')->first();
        return $assign;
    }

    public function getInv(Request $request) {
        $assign = DB::table('inventoryorgs')->where('invcode', $request->invcode)->pluck('invname')->first();
        return $assign;
    }

    public function getItem(Request $request) {
        $assign = DB::table('items')->where('itemcode', $request->itemcode)->pluck('itemdes')->first();
        return $assign;
    }
}
