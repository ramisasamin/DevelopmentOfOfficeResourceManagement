<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Ilocation;
use App\Models\Inventoryorg;
use App\Models\Ledger;
use Illuminate\Support\Facades\Auth;
use App\Models\Legal;
use App\Models\Unit;
use Illuminate\Http\Request;

class InventoryorgsController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('invorganization.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }
        $inventoryorgs = Inventoryorg::all();
        $units = Unit::all();
        return view('backend.pages.inventoryorgs.index', compact('inventoryorgs', 'units'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('invorganization.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        $inventoryorgs = Inventoryorg::all();
        $ilocations = Ilocation::all();
        $ledgers = Ledger::all();
        $legals = Legal::all();
        $units = Unit::all();
        return view('backend.pages.inventoryorgs.create', compact('inventoryorgs', 'ilocations', 'ledgers', 'legals', 'units'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        if (is_null($this->user) || !$this->user->can('invorganization.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }
        // Create New User
        $inventoryorg = new Inventoryorg();

        $inventoryorg->istart = $request->istart;
        $inventoryorg->iend = $request->iend;
        $inventoryorg->lname = $request->lname;
        $inventoryorg->ladd = $request->ladd;
        $inventoryorg->invcode = $request->invcode;
        $inventoryorg->invname = $request->invname;
        $inventoryorg->ledgername = $request->ledgername;
        $inventoryorg->legalname = $request->legalname;
        $inventoryorg->shortname = $request->shortname;

        // $user->password = Hash::make($request->password);
        $inventoryorg->save();

        // if ($request->roles) {
        //     $user->assignRole($request->roles);
        // }

        session()->flash('success', 'Inventory Organization has been created !!');
        return redirect()->route('inventoryorgs.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (is_null($this->user) || !$this->user->can('invorganization.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        $inventoryorg = Inventoryorg::find($id);
        $inventoryorgs = Inventoryorg::all();
        $ilocations = Ilocation::all();
        $ledgers = Ledger::all();
        $legals = Legal::all();
        $units = Unit::all();
        return view('backend.pages.inventoryorgs.edit', compact('inventoryorg', 'inventoryorgs', 'ilocations', 'ledgers', 'legals', 'units'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (is_null($this->user) || !$this->user->can('invorganization.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }
        // Create New User
        $inventoryorg = Inventoryorg::find($id);

        $inventoryorg->istart = $request->istart;
        $inventoryorg->iend = $request->iend;
        $inventoryorg->lname = $request->lname;
        $inventoryorg->ladd = $request->ladd;
        $inventoryorg->invcode = $request->invcode;
        $inventoryorg->invname = $request->invname;
        $inventoryorg->ledgername = $request->ledgername;
        $inventoryorg->legalname = $request->legalname;
        $inventoryorg->shortname = $request->shortname;


        $inventoryorg->save();


        session()->flash('success', 'Inventory Organization has been updated !!');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if (is_null($this->user) || !$this->user->can('invorganization.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }
        $inventoryorg = Inventoryorg::find($id);
        if (!is_null($inventoryorg)) {
            $inventoryorg->delete();
        }

        session()->flash('success', 'Inventory Organization has been deleted !!');
        return back();
    }
}
