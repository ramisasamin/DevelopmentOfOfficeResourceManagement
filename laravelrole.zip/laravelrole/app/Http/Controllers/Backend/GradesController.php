<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Grade;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class GradesController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('manage.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }
        $grades = Grade::all();
        return view('backend.pages.grades.index', compact('grades'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }
        $grades = Grade::all();
        return view('backend.pages.grades.create', compact('grades'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (is_null($this->user) || !$this->user->can('manage.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }
        // Validation Data
        $request->validate([
            'gradename' => 'required|max:200',
            'gradename' => 'required|max:200',
            'gradename' => 'required|max:200',
        ]);

        // Create New User
        $grade = new Grade();

        $grade->gradenumber = $request->gradenumber;
        $grade->gradename = $request->gradename;
        $grade->gradecode = $request->gradecode;

        // $user->password = Hash::make($request->password);
        $grade->save();

        // if ($request->roles) {
        //     $user->assignRole($request->roles);
        // }

        session()->flash('success', 'Grade has been created !!');
        return redirect()->route('grades.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }
        $grade = Grade::find($id);
        $grades = Grade::all();
        return view('backend.pages.grades.edit', compact('grade', 'grades'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        if (is_null($this->user) || !$this->user->can('manage.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }
        // Create New User
        $grade = Grade::find($id);

        // Validation Data
        $request->validate([
            'gradename' => 'required|max:200',
            'gradename' => 'required|max:200',
            'gradename' => 'required|max:200'. $id,

        ]);

        $grade->gradenumber = $request->gradenumber;
        $grade->gradename = $request->gradename;
        $grade->gradecode = $request->gradecode;

        $grade->save();


        session()->flash('success', 'Grade has been updated !!');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {

        if (is_null($this->user) || !$this->user->can('manage.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }
        $grade = Grade::find($id);
        if (!is_null($grade)) {
            $grade->delete();
        }

        session()->flash('success', 'Grade has been deleted !!');
        return back();
    }
}
