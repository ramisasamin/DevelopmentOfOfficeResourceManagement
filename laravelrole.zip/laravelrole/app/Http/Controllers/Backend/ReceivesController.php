<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Receive;
use Illuminate\Support\Facades\Auth;
use App\Models\Item;
use App\Models\User;
use App\Models\Assign;

use Illuminate\Support\Facades\DB;

class ReceivesController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

    public function create()
    {
        if (is_null($this->user) || !$this->user->can('receiveitem.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        $receives = Receive::all();
        $items = Item::all();
        $users = User::all();
        $assigns = Assign::all();


        return view('backend.pages.receives.create', compact('receives', 'items', 'users', 'assigns'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        if (is_null($this->user) || !$this->user->can('receiveitem.create')) {
            abort(403, 'Sorry !! You are Unauthorized to create any admin !');
        }

        // Create New User
        $receive = new Receive();

        $receive->eid = $request->eid;
        $receive->itemcode = $request->itemcode;
        $receive->itemdes = $request->itemdes;
        $receive->rdate = $request->rdate;
        $receive->ri = $request->ri;

        // $user->password = Hash::make($request->password);
        $receive->save();

        // if ($request->roles) {
        //     $user->assignRole($request->roles);
        // }

        session()->flash('success', 'Receive has been created !!');
        return redirect()->route('receives.create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (is_null($this->user) || !$this->user->can('receiveitem.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        $receive = Receive::find($id);
        $receives = Receive::all();
        $items = Item::all();
        $users = User::all();

        return view('backend.pages.receives.edit', compact('receive', 'receives', 'items', 'users'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (is_null($this->user) || !$this->user->can('receiveitem.edit')) {
            abort(403, 'Sorry !! You are Unauthorized to edit any admin !');
        }

        // Create New User
        $receive = Receive::find($id);

        $receive->eid = $request->eid;
        $receive->itemcode = $request->itemcode;
        $receive->itemdes = $request->itemdes;
        $receive->rdate = $request->rdate;
        $receive->ri = $request->ri;

        $receive->save();


        session()->flash('success', 'Receive has been updated !!');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if (is_null($this->user) || !$this->user->can('receiveitem.delete')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }


        $receive = Receive::find($id);
        if (!is_null($receive)) {
            $receive->delete();
        }

        session()->flash('success', 'Receive has been deleted !!');
        return back();
    }
    public function getItemcode(Request $request) {
        $receive = DB::table('assigns')->where('eid', $request->eid)->pluck('itemcode')->first();
        return $receive;
    }
    public function getItem(Request $request) {
        $receive = DB::table('assigns')->where('itemcode', $request->itemcode)->pluck('itemdes')->first();
        return $receive;
    }
}
