<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Receive extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $guarded = [];

    protected $fillable = ['eid','itemcode', 'itemdes', 'rdate' , 'ri'];

    public function receive()
    {
        return $this->belongsTo(Receive::class)->withDefault();
    }
    public function assign()
    {
        return $this->hasMany('App\Assign');

    }
}
