<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Inventoryorg extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $guarded = [];

    public function inventoryorg()
    {
        return $this->belongsTo(Inventoryorg::class)->withDefault();
    }
}
