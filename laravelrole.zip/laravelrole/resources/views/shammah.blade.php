@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Employee Profile</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><a href="{{ route('users.index') }}">All Employee</a></li>
                    <li><span>Profile Employee - {{ $user->name }}</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Profile Employee - {{ $user->name }}</h4>
                    @include('backend.layouts.partials.messages')

                    <form action="{{ route('users.update', $user->id) }}" method="POST">
                        {{-- @method('PUT') --}}
                        <div class="form-row">
                            <div class="form-group col-md-2 col-sm-12">
                                <label for="titlename">Title</label>
                                <select name="titlename" id="titlename" class="form-control">
                                    {{-- <option selected>Choose...</option> --}}
                                    @foreach ($titles as $title)
                                        <option value="{{ $title->titlename }}" {{ $title->titlename == $user->titlename ? 'selected': ''}}>{{ $title->titlename }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="name">First Name</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Enter First Name" value="{{ $user->name }}">
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="namel">Last name</label>
                                <input type="text" class="form-control" id="namel" name="namel" placeholder="Enter Last Email" value="{{ $user->namel }}">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="fname">Father's Name</label>
                                <input type="text" class="form-control" id="fname" name="fname" placeholder="Enter Father's Name" value="{{ $user->fname }}">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="fno">Father's Phone Number</label>
                                <input type="text" class="form-control" id="fno" name="fno" placeholder="Enter Father's Number" value="{{ $user->fno }}">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="mname">Mother's Name</label>
                                <input type="text" class="form-control" id="mname" name="mname" placeholder="Enter Mother's Name" value="{{ $user->mname }}">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="mno">Mother's Phone Number</label>
                                <input type="text" class="form-control" id="mno" name="mno" placeholder="Enter Mother's Number" value="{{ $user->mno }}">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="gendername">Gender</label>
                                <select name="gendername" id="gendername" class="form-control"  value="{{ $user->mno }}" >
                                    <!-- <option selected>Choose...</option> -->
                                    @foreach ($genders as $gender)
                                        <option value="{{ $gender->gendername }}" {{ $gender->gendername == $user->gendername ? 'selected': ''}}>{{ $gender->gendername }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="systemtype">Emploment Type</label>
                                <select name="systemtype" id="systemtype" class="form-control" value="{{ $user->systemtype }}" >
                                    <!-- <option selected>Choose...</option> -->
                                    @foreach ($persontypes as $ptype)
                                        <option value="{{ $ptype->systemtype }}" {{ $ptype->systemtype == $user->systemtype ? 'selected': ''}}>{{ $ptype->systemtype }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="eid">Office ID</label>
                                <input type="text" class="form-control" id="eid" name="eid" placeholder="Enter ID" value="{{ $user->eid }}">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="nid">NID</label>
                                <input type="text" class="form-control" id="nid" name="nid" placeholder="Enter NID" value="{{ $user->nid }}">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-2 col-sm-12">
                                <br><label>Effective Dates: </label>
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="start">From</label>
                                <input class="form-control" type="date" id="start" name="start" value="{{ $user->start }}">
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="end">To</label>
                                <input class="form-control" type="date" id="end" name="end" value="{{ $user->end }}">
                            </div>
                        </div>

                        <hr>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <h5 style="color: black">Personal Information</h5>
                                <br>
                                <div class="form-group col-md-12">
                                    <label for="bd">Date of Birth</label>
                                    <input class="form-control" type="date" id="bd" name="bd" placeholder="Enter Date of Birth" value="{{ $user->bd }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="place">Place of Birth</label>
                                    <input class="form-control" type="date" id="place" name="place" placeholder="Enter Place of Birth" value="{{ $user->place }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="maritalstatus">Marital Status</label>
                                    <select name="" id="maritalstatus" class="form-control" value="{{ $user->maritalstatus }}">
                                        <!-- <option selected>Choose...</option> -->
                                        @foreach ($maritals as $marital)
                                            <option value="{{ $marital->maritalstatus }}" {{ $marital->maritalstatus == $user->maritalstatus ? 'selected': ''}}>{{ $marital->maritalstatus }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="nationalityname">Nationality</label>
                                    <select name="" id="nationalityname" class="form-control" value="{{ $user->nationalityname }}">
                                        <!-- <option selected>Choose...</option> -->
                                        @foreach ($nationalities as $nationality)
                                            <option value="{{ $nationality->nationalityname }}" {{ $nationality->nationalityname == $user->nationalityname ? 'selected': ''}}>{{ $nationality->nationalityname }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Upload Picture</label>
                                    <div class="form-group col-md-12">
                                    <input type="file" class="custom-file-input" id="image" name="image" value="{{ $user->image }}" >
                                    <label class="custom-file-label" for="image">Choose file</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <h5 style="color: black">Office Details</h5>
                                <br>
                                <div class="form-group col-md-12">
                                    <label for="office">Office</label>
                                    <input type="text" class="form-control" id="office" name="office" placeholder="Enter Office" value="{{ $user->office }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="address">Address</label>
                                    <input type="text" class="form-control" id="address" name="address" placeholder="Enter Address" value="{{ $user->address }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="mail">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" value="{{ $user->email }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="ono">Office Mobile Number</label>
                                    <input type="text" class="form-control" id="ono" name="ono" placeholder="Enter Phone Number" value="{{ $user->ono }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="pno">Personal Mobile Number</label>
                                    <input type="text" class="form-control" id="pno" name="pno" placeholder="Enter Phone Number" value="{{ $user->pno }}">
                                </div>
                            </div>
                        </div>

                        <hr>
                        <h5 style="color: black">Assignment</h5>
                        <br>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="shortname">Organization</label>
                                <select name="" id="shortname" class="form-control"  value="{{ $user->shortname }}">
                                    <!-- <option selected>Choose...</option> -->
                                    @foreach ($units as $unit)
                                        <option value="{{ $unit->shortname }}" {{ $unit->shortname == $user->shortname ? 'selected': ''}}>{{ $unit->shortname }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="statusassign">Status</label>
                                <select name="" id="statusassign" class="form-control" value="{{ $user->statusassign }}">
                                    <!-- <option selected>Choose...</option> -->
                                    @foreach ($statuses as $status)
                                        <option value="{{ $status->statusassign }}" {{ $status->statusassign == $user->statusassign ? 'selected': ''}}>{{ $status->statusassign }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="jobname">Job Position</label>
                                <select name="" id="jobname" class="form-control"  value="{{ $user->jobname }}">
                                    <!-- <option selected>Choose...</option> -->
                                    @foreach ($jobs as $job)
                                        <option value="{{ $job->jobname }}" {{ $job->jobname == $user->jobname ? 'selected': ''}}>{{ $job->jobname }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="sscale">Salary Scale</label>
                                <input type="text" class="form-control" id="sscale" name="sscale" placeholder="Enter Salary Scale" value="{{ $user->sscale }}">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="gradecode">Grade</label>
                                <select name="" id="gradecode" class="form-control" value="{{ $user->gradecode }}">
                                    <!-- <option selected>Choose...</option> -->
                                    @foreach ($grades as $grade)
                                        <option value="{{ $grade->gradecode }}" {{ $grade->gradecode == $user->gradecode ? 'selected': ''}}>{{ $grade->gradecode }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="supname">Supervisor's Name</label>
                                <input type="text" class="form-control" id="supname" name="supname" placeholder="Enter Supervisor's Name" value="{{ $user->supname }}">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="locationcode">Location</label>
                                <select name="" id="locationcode" class="form-control"  value="{{ $user->locationcode }}">
                                    <!-- <option selected>Choose...</option> -->
                                    @foreach ($locations as $location)
                                        <option value="{{ $location->locationcode }}" {{ $location->locationcode == $user->locationcode ? 'selected': ''}}>{{ $location->locationcode }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="supno">Supervisor's Number</label>
                                <input type="text" class="form-control" id="supno" name="supno" placeholder="Enter Supervisor's Number" value="{{ $user->supno }}">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="assignno">Assignment Number</label>
                                <input type="text" class="form-control" id="assignno" name="assignno" placeholder="Enter Assignment Number" value="{{ $user->assignno }}">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="period">Probation Period Length</label>
                                <input type="text" class="form-control" id="period" name="period" placeholder="Enter Period Length" value="{{ $user->period }}">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="categoryname">Assignment Category</label>
                                <select name="" id="categoryname" class="form-control" value="{{ $user->categoryname }}">
                                    <!-- <option selected>Choose...</option> -->
                                    @foreach ($categories as $category)
                                        <option value="{{ $category->categoryname }}" {{ $category->categoryname == $user->categoryname ? 'selected': ''}}>{{ $category->categoryname }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="periodend">Probation Period End</label>
                                <input type="text" class="form-control" id="periodend" name="periodend" placeholder="Enter Period End" value="{{ $user->periodend }}">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="grp">Group</label>
                                <select class="form-control" id="grp" name="grp" value="{{ $user->grp }}">
                                    <!-- <option selected>Choose...</option> -->
                                    <option value="1">PSG</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="notice">Notice Period Length</label>
                                <input type="text" class="form-control" id="notice" name="notice" placeholder="Enter Period Length" value="{{ $user->notice }}">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="positionname">Position</label>
                                <select name="" id="positionname" class="form-control"  value="{{ $user->positionname }}">
                                    <!-- <option selected>Choose...</option> -->
                                    @foreach ($positions as $position)
                                        <option value="{{ $position->positionname }}" {{ $position->positionname == $user->positionname ? 'selected': ''}}>{{ $position->positionname }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="whour">Working Hours</label>
                                <input type="text" class="form-control" id="whour" name="whour" placeholder="Enter Working Hours" value="{{ $user->whour }}">
                            </div>
                        </div>

                        <hr>
                        <h5 style="color: black">Salary Determination</h5>
                        <br>

                        <div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="shr">Salary/Hour</label>
                                <input type="text" class="form-control" id="shr" name="shr" placeholder="Enter Amount" value="{{ $user->shr }}">
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-2 col-sm-12">
                                    <br><label>Working Hours</label>
                                </div>
                                <div class="form-group col-md-5 col-sm-12">
                                    <input class="form-control" type="time" id="stime" name="stime">
                                </div>
                                <div class="form-group col-md-5 col-sm-12">
                                    <input class="form-control" type="time" id="etime" name="etime">
                                </div>
                            </div>
                            <br>
                            <div class="form-check">
                                <label class="form-check-label">
                                  <input type="checkbox" class="form-check-input" value="checkbox" {{ $user->checkbox == 'checkbox' ? 'checked' : '' }}>Work from Home
                                </label>
                            </div>
                            <br>
                            <div class="form-row">
                                <div class="form-group col-md-2 col-sm-12">
                                    <br><label>Effective Dates</label>
                                </div>
                                <div class="form-group col-md-5 col-sm-12">
                                    <input class="form-control" type="date" id="datestart" name="datestart" value="{{ $user->datestart }}">
                                </div>
                                <div class="form-group col-md-5 col-sm-12">
                                    <input class="form-control" type="date" id="dateend" name="dateend" value="{{ $user->dateend }}">
                                </div>
                            </div>
                        </div>

                        <div class="hidden-print">
                            <div class="pull-right">
                                <a href="#" onclick="window.print()" class="btn btn-primary mt-4 pr-4 pl-4"><i class="fa fa-print">Print</i></a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
@endsection
