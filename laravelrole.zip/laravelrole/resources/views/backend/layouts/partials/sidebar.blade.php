 <!-- sidebar menu area start -->

 @php
 $usr = Auth::guard('admin')->user();
@endphp

 <div class="sidebar-menu">
    <div class="sidebar-header">
        <div class="logo">
            <a href="{{ route('admin.dashboard') }}">
                <h5 class="text-white">Office Resource Management System</h5>
            </a>
        </div>

    </div>
    <div class="main-menu">
        <div class="menu-inner">
            <nav>
                <ul class="metismenu" id="menu">

                    @if ($usr->can('dashboard.view'))
                    <li class="active">
                        <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>dashboard</span></a>
                        <ul class="collapse">
                            <li class="{{ Route::is('admin.dashboard') ? 'active' : '' }}"><a href="{{ route('admin.dashboard') }}">Overview Board</a></li>
                        </ul>
                    </li>
                    @endif

                    @if ($usr->can('role.create') || $usr->can('role.view') ||  $usr->can('role.edit') ||  $usr->can('role.delete'))
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-tasks"></i><span>
                            Roles & Permissions
                        </span></a>
                        <ul class="collapse {{ Route::is('roles.create') || Route::is('roles.index') || Route::is('roles.edit') || Route::is('roles.show') ? 'in' : '' }}">
                            @if ($usr->can('role.view'))
                                <li class="{{ Route::is('roles.index')  || Route::is('roles.edit') ? 'active' : '' }}"><a href="{{ route('roles.index') }}">All Roles</a></li>
                            @endif
                            @if ($usr->can('role.create'))
                                <li class="{{ Route::is('roles.create')  ? 'active' : '' }}"><a href="{{ route('roles.create') }}">Create Role</a></li>
                            @endif
                        </ul>
                    </li>
                    @endif

                    @if ($usr->can('admin.create') || $usr->can('admin.view') ||  $usr->can('admin.edit') ||  $usr->can('admin.delete'))
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i><span>
                            Admins
                        </span></a>
                        <ul class="collapse {{ Route::is('admins.create') || Route::is('admins.index') || Route::is('admins.edit') || Route::is('admins.show') ? 'in' : '' }}">

                            @if ($usr->can('admin.view'))
                                <li class="{{ Route::is('admins.index')  || Route::is('admins.edit') ? 'active' : '' }}"><a href="{{ route('admins.index') }}">All Admins</a></li>
                            @endif

                            @if ($usr->can('admin.create'))
                                <li class="{{ Route::is('admins.create')  ? 'active' : '' }}"><a href="{{ route('admins.create') }}">Create Admin</a></li>
                            @endif
                        </ul>
                    </li>
                    @endif

                    @if ($usr->can('employee.create') || $usr->can('employee.view') ||  $usr->can('employee.edit') ||  $usr->can('employee.delete'))
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i><span>
                            Employees
                        </span></a>
                        <ul class="collapse {{ Route::is('users.create') || Route::is('users.index') || Route::is('users.edit') || Route::is('users.show') ? 'in' : '' }}">
                            @if ($usr->can('employee.view'))
                            <li class="{{ Route::is('users.index')  || Route::is('users.edit') ? 'active' : '' }}"><a href="{{ route('users.index') }}">All Employees</a></li>
                            @endif
                            @if ($usr->can('employee.create'))
                            <li class="{{ Route::is('users.create')  ? 'active' : '' }}"><a href="{{ route('users.create') }}">Add Employee</a></li>
                            @endif
                        </ul>
                    </li>
                    @endif

                    @if ($usr->can('manage.create') || $usr->can('manage.view') ||  $usr->can('manage.edit') ||  $usr->can('manage.delete'))
                    <li>
                    <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i>
                        <span>
                            HRMS Management
                        </span>
                    </a>
                        <ul class="collapse {{
                        Route::is('units.create') || Route::is('units.index') || Route::is('units.edit') || Route::is('units.show') ||
                        Route::is('jobs.create')  || Route::is('jobs.index')  || Route::is('jobs.edit') || Route::is('jobs.show') ||
                        Route::is('positions.create')  || Route::is('positions.index') || Route::is('positions.edit') || Route::is('positions.show') ||
                        Route::is('grades.create')  || Route::is('grades.index') || Route::is('grades.edit') || Route::is('grades.show') ||
                        Route::is('categories.create')  || Route::is('categories.index') || Route::is('categories.edit') || Route::is('categories.show') ||
                        Route::is('locations.create')  || Route::is('locations.index') || Route::is('locations.edit') || Route::is('locations.show') ||
                        Route::is('nationalities.create')  || Route::is('nationalities.index') || Route::is('nationalities.edit') || Route::is('nationalities.show') ||
                        Route::is('legals.create')  || Route::is('legals.index') || Route::is('legals.edit') || Route::is('legals.show') ||
                        Route::is('ledgers.create')  || Route::is('ledgers.index') || Route::is('ledgers.edit') || Route::is('ledgers.show')
                        ? 'in' : '' }}">
                        @if ($usr->can('manage.view'))

                            <li class="{{ Route::is('units.index')  || Route::is('units.edit') ? 'active' : '' }}"><a href="{{ route('units.index') }}">Organizations</a></li>
                            <li class="{{ Route::is('jobs.index')  || Route::is('jobs.edit') ? 'active' : '' }}"><a href="{{ route('jobs.index') }}">Job</a></li>
                            <li class="{{ Route::is('positions.index')  || Route::is('positions.edit') ? 'active' : '' }}"><a href="{{ route('positions.index') }}">Position</a></li>
                            <li class="{{ Route::is('grades.index')  || Route::is('grades.edit') ? 'active' : '' }}"><a href="{{ route('grades.index') }}">Grade</a></li>
                            <li class="{{ Route::is('categories.index')  || Route::is('categories.edit') ? 'active' : '' }}"><a href="{{ route('categories.index') }}">Category</a></li>
                            <li class="{{ Route::is('locations.index')  || Route::is('locations.edit') ? 'active' : '' }}"><a href="{{ route('locations.index') }}">Location</a></li>
                            <li class="{{ Route::is('nationalities.index')  || Route::is('nationalities.edit') ? 'active' : '' }}"><a href="{{ route('nationalities.index') }}">Nationality</a></li>
                            <li class="{{ Route::is('legals.index')  || Route::is('legals.edit') ? 'active' : '' }}"><a href="{{ route('legals.index') }}">Legal Entity</a></li>
                            <li class="{{ Route::is('ledgers.index')  || Route::is('ledgers.edit') ? 'active' : '' }}"><a href="{{ route('ledgers.index') }}">Ledger</a></li>

                        @endif
                        </ul>
                    </li>
                    @endif

                    @if ($usr->can('invorganization.create') || $usr->can('invorganization.view') ||  $usr->can('invorganization.edit') ||  $usr->can('invorganization.delete') ||
                    $usr->can('invlocation.create') || $usr->can('invlocation.view') ||  $usr->can('invlocation.edit') ||  $usr->can('invlocation.delete') ||
                    $usr->can('invtransaction.create') || $usr->can('invtransaction.view') ||  $usr->can('invtransaction.edit') ||  $usr->can('invtransaction.delete') ||
                    $usr->can('invonhand.view'))
                    <li>
                    <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i>
                        <span>
                            Inventory
                        </span>
                    </a>
                        <ul class="collapse {{
                        Route::is('inventoryorgs.create') || Route::is('inventoryorgs.index') || Route::is('inventoryorgs.edit') || Route::is('inventoryorgs.show') ||
                        Route::is('ilocations.create') || Route::is('ilocations.index') || Route::is('ilocations.edit') || Route::is('ilocations.show') ||
                        Route::is('transactions.create') || Route::is('transactions.index') || Route::is('transactions.edit') || Route::is('transactions.show') ||
                        Route::is('onhands.index')
                        ? 'in' : '' }}">
                            @if ($usr->can('invorganization.view'))
                            <li class="{{ Route::is('inventoryorgs.index')  || Route::is('inventoryorgs.edit') ? 'active' : '' }}"><a href="{{ route('inventoryorgs.index') }}">Inventory Organization</a></li>
                            @endif
                            @if ($usr->can('invlocation.view'))
                            <li class="{{ Route::is('ilocations.index')  || Route::is('ilocations.edit') ? 'active' : '' }}"><a href="{{ route('ilocations.index') }}">Location</a></li>
                            @endif
                            @if ($usr->can('invtransaction.view'))
                            <li class="{{ Route::is('transactions.index')  || Route::is('transactions.edit') ? 'active' : '' }}"><a href="{{ route('transactions.index') }}">Transaction</a></li>
                            @endif
                            @if ($usr->can('invonhand.view'))
                            <li class="{{ Route::is('onhands.index') ? 'active' : '' }}"><a href="{{ route('onhands.index') }}">On-hand Availability</a></li>
                            @endif
                        </ul>
                    </li>
                    @endif

                    @if ($usr->can('item.create') || $usr->can('item.view') ||  $usr->can('item.edit') ||  $usr->can('item.delete'))
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i>
                            <span>
                                Item
                            </span>
                        </a>
                            <ul class="collapse {{ Route::is('items.create') || Route::is('items.index') || Route::is('items.edit') || Route::is('items.show') ? 'in' : '' }}">
                                @if ($usr->can('item.view'))
                                <li class="{{ Route::is('items.index')  || Route::is('items.edit') ? 'active' : '' }}"><a href="{{ route('items.index') }}">Master Item</a></li>
                                @endif
                            </ul>
                    </li>
                    @endif

                    @if ($usr->can('assignitem.create') || $usr->can('assignitem.view') ||  $usr->can('assignitem.edit') ||  $usr->can('assignitem.delete') ||
                    $usr->can('receiveitem.create') || $usr->can('receiveitem.view') ||  $usr->can('receiveitem.edit') ||  $usr->can('receiveitem.delete'))
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i>
                            <span>
                                Track of Item
                            </span>
                        </a>
                            <ul class="collapse {{
                            Route::is('assigns.create') || Route::is('assigns.index') || Route::is('assigns.edit') || Route::is('assigns.show') ||
                            Route::is('receives.create') || Route::is('receives.edit') || Route::is('receives.show') ? 'in' : ''
                            }}">
                                @if ($usr->can('assignitem.view'))
                                <li class="{{ Route::is('assigns.index')  || Route::is('assigns.edit') ? 'active' : '' }}"><a href="{{ route('assigns.index') }}">Item Information</a></li>
                                @endif
                                @if ($usr->can('assignitem.create'))
                                <li class="{{ Route::is('assigns.create')  ? 'active' : '' }}"><a href="{{ route('assigns.create') }}">Assign Item</a></li>
                                @endif
                                @if ($usr->can('receiveitem.view'))
                                <li class="{{ Route::is('receives.create')  ? 'active' : '' }}"><a href="{{ route('receives.create') }}">Receive Item</a></li>
                                @endif
                            </ul>
                    </li>
                    @endif

                </ul>
            </nav>
        </div>
    </div>
</div>
<!-- sidebar menu area end -->


{{-- <li class="active">
    <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>dashboard</span></a>
    <ul class="collapse">
        <li class="{{ Route::is('admin.dashboard') ? 'active' : '' }}"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
    </ul>
</li>

<li>
    <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>
        Roles & Permissions
    </span></a>
    <ul class="collapse {{ Route::is('roles.create') || Route::is('roles.index') || Route::is('roles.edit') || Route::is('roles.show') ? 'in' : '' }}">
        <li class="{{ Route::is('roles.index')  || Route::is('roles.edit') ? 'active' : '' }}"><a href="{{ route('roles.index') }}">All Roles</a></li>
        <li class="{{ Route::is('roles.create')  ? 'active' : '' }}"><a href="{{ route('roles.create') }}">Create Role</a></li>
    </ul>
</li>

<li>
    <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i><span>
        Admin
    </span></a>
    <ul class="collapse {{ Route::is('admins.create') || Route::is('admins.index') || Route::is('admins.edit') || Route::is('admins.show') ? 'in' : '' }}">
        <li class="{{ Route::is('admins.index')  || Route::is('admins.edit') ? 'active' : '' }}"><a href="{{ route('admins.index') }}">All Admins</a></li>
        <li class="{{ Route::is('admins.create')  ? 'active' : '' }}"><a href="{{ route('admins.create') }}">Create Admin</a></li>
    </ul>
</li> --}}
