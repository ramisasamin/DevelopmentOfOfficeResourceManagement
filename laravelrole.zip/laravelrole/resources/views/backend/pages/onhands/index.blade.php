@extends('backend.layouts.master')

@section('title')
On-Hand Availabilities - Admin Panel
@endsection

@section('styles')
    <!-- Start datatable css -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
@endsection

@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-onhands-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">On-Hand Availabilities</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><span>All On-Hand Availabilities</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title float-left">On-Hand Availabilities List</h4>
                    @include('backend.layouts.partials.messages')
                    <div class="clearfix"></div>
                    <div>
                        <form action="{{ route('onhands.find') }}" method="POST">
                            @csrf
                            <div class="form-row">
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="invcode">Inventory Code</label>
                                    <select name="invcode" id="invcode" class="form-control">
                                        <option value="0" disabled="true" selected="true">-Select-</option>
                                        @foreach ($inventoryorgs as $inventoryorg)
                                            <option value="{{ $inventoryorg->invcode }}">{{ $inventoryorg->invcode }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="invname">Inventory Name</label>
                                    <input type="text" class="form-control" id="invname" name="invname" placeholder="Enter Inventory Name">
                                </div>

                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="itemcode">Item Code</label>
                                    <select name="itemcode" id="itemcode" class="form-control">
                                        <option value="0" disabled="true" selected="true">-Select-</option>
                                        @foreach ($items as $item)
                                            <option value="{{ $item->itemcode }}">{{ $item->itemcode }}</option>
                                        @endforeach
                                    </select>
                                    {{-- <input type="text" class="form-control" id="itemcode" name="itemcode" placeholder="Enter Item Code"> --}}
                                </div>

                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="itemdes">Item Description</label>
                                    <input type="text" class="form-control" id="itemdes" name="itemdes" readonly='true' placeholder="Enter Item Description">
                                </div>

                                <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Find</button>
                            </div>
                        </form>
                    </div>

                    <br><br>

                    <div class="clearfix"></div>
                    <div class="data-tables">

                        <table id="dataTable" class="text-center">
                            <thead class="bg-light text-capitalize">
                                <tr>
                                    <th>Inventory Code</th>
                                    <th>Item code</th>
                                    <th>Item Description</th>
                                    <th>UOM</th>
                                    <th>On-Hand</th>
                                    <th>view</th>
                                </tr>
                            </thead>
                            <tbody>
                               @foreach ($items as $item)
                               <tr>
                                   <td>{{ $item->invcode }}</td>
                                   <td>{{ $item->itemcode }}</td>
                                   <td>{{ $item->itemdes }}</td>
                                   <td>{{ $item->measure }}</td>
                                   <td>{{ $item->quantity }}</td>
                                   <td>-</td>
                               </tr>
                               @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="hidden-print">
                        <div class="pull-right">
                            <a href="#" onclick="window.print()" class="btn btn-primary mt-4 pr-4 pl-4"><i class="fa fa-print">Print</i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
@endsection


@section('scripts')
     <!-- Start datatable js -->
     <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
     <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
     <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
     <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
     <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>

     <script>
         /*================================
        datatable active
        ==================================*/
        if ($('#dataTable').length) {
            $('#dataTable').DataTable({
                responsive: true
            });
        }
        $('#invcode').on('input', function(e){
            var invcode_ = $('#invcode option:selected').val();
            $.ajax({
                type:"GET",
                url:"{{ url('onhands/getinv') }}",
                data:{
                    invcode: invcode_
                },
                success: function(data){
                    if(data){
                        $('#invname').val(data);
                    }else{
                        $('#invname').val('');
                    }
                }
            });

        });
        $('#itemcode').on('input', function(e){
           var itemcode_ = $('#itemcode option:selected').val();
           $.ajax({
               type:"GET",
               url:"{{ url('onhands/getitem') }}",
               data:{
                itemcode: itemcode_
               },
               success: function(data){
                   if(data){
                       $('#itemdes').val(data);
                   }else{
                       $('#itemdes').val('');
                   }
               }
           });

       });
     </script>

@endsection
