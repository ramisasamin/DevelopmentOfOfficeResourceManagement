@extends('backend.layouts.master')

@section('title')
Inventory Locations Edit - Admin Panel
@endsection

@section('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Inventory Location Edit</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><a href="{{ route('inventoryorgs.index') }}">All Inventory Locations</a></li>
                    <li><span>Edit Inventory</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit Inventory - {{ $inventoryorg->lname }}</h4>
                    @include('backend.layouts.partials.messages')

                    <form action="{{ route('inventoryorgs.update', $inventoryorg->id) }}" method="POST">
                        {{-- @method('PUT') --}}
                        @csrf

                        <div class="form-row">
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="istart">Date From</label>
                                <input class="form-control" type="date" id="istart" name="istart" value="{{ $inventoryorg->istart }}">
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="iend">Date To</label>
                                <input class="form-control" type="date" id="iend" name="iend" value="{{ $inventoryorg->iend }}">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="lname">Location</label>
                                <select name="lname" id="lname" class="form-control" value="{{ $inventoryorg->lname }}" >
                                    <!-- <option selected>Choose...</option> -->
                                    @foreach ($ilocations as $ilocation)
                                        <option value="{{ $ilocation->lname }}">{{ $ilocation->lname }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="ladd">Location Address</label>
                                <select name="ladd" id="ladd" class="form-control" value="{{ $inventoryorg->ladd }}">
                                    <!-- <option selected>Choose...</option> -->
                                    @foreach ($ilocations as $ilocation)
                                        <option value="{{ $ilocation->ladd }}">{{ $ilocation->ladd }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="invcode">Inventory Code</label>
                                <input type="text" class="form-control" id="invcode" name="invcode" placeholder="Enter Inventory Code" value="{{ $inventoryorg->invcode }}">
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="invname">Inventory name</label>
                                <input type="text" class="form-control" id="invname" name="invname" placeholder="Enter Inventory name" value="{{ $inventoryorg->invname }}">
                            </div>
                        </div>

                        <div class="form-group col-md-6 col-sm-12">
                            <label for="ledgername">Primary Ledger</label>
                            <select name="ledgername" id="ledgername" class="form-control" value="{{ $inventoryorg->ledgername }}">
                                <!-- <option selected>Choose...</option> -->
                                @foreach ($ledgers as $ledger)
                                    <option value="{{ $ledger->ledgername }}">{{ $ledger->ledgername }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group col-md-6 col-sm-12">
                            <label for="legalname">Legal Entity</label>
                            <select name="legalname" id="legalname" class="form-control" value="{{ $inventoryorg->legalname }}">
                                <!-- <option selected>Choose...</option> -->
                                @foreach ($legals as $legal)
                                    <option value="{{ $legal->legalname }}">{{ $legal->legalname }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group col-md-6 col-sm-12">
                            <label for="shortname">Organization</label>
                            <select name="shortname" id="shortname" class="form-control" value="{{ $inventoryorg->shortname }}">
                                <!-- <option selected>Choose...</option> -->
                                @foreach ($units as $unit)
                                    <option value="{{ $unit->shortname }}">{{ $unit->shortname }}</option>
                                @endforeach
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save Inventory Information</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
@endsection
