@extends('backend.layouts.master')

@section('title')
Inventory Locations Edit - Admin Panel
@endsection

@section('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Inventory Edit</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><a href="{{ route('ilocations.index') }}">All Inventory Locations</a></li>
                    <li><span>Edit Inventory</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit Inventory - {{ $ilocation->lname }}</h4>
                    @include('backend.layouts.partials.messages')

                    <form action="{{ route('ilocations.update', $ilocation->id) }}" method="POST">
                        {{-- @method('PUT') --}}
                        @csrf

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <div class="form-group col-md-12">
                                    <label for="lname">Location Name</label>
                                    <input class="form-control" type="text" id="lname" name="lname" placeholder="Enter Location Name" value="{{ $ilocation->lname }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="ldescription">Description</label>
                                    <input class="form-control" type="text" id="ldescription" name="ldescription" placeholder="Enter Description" value="{{ $ilocation->ldescription }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="linactivedate">Inactive Date</label>
                                    <input class="form-control" type="text" id="linactivedate" name="linactivedate" placeholder="Enter Inactive Date" value="{{ $ilocation->linactivedate }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="ladd">Address</label>
                                    <input class="form-control" type="text" id="ladd" name="ladd" placeholder="Enter Address" value="{{ $ilocation->ladd }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="lcity">City</label>
                                    <input class="form-control" type="text" id="lcity" name="lcity" placeholder="Enter City" value="{{ $ilocation->lcity }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="lregion">Region</label>
                                    <input class="form-control" type="text" id="lregion" name="lregion" placeholder="Enter Region" value="{{ $ilocation->lregion }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="lcountry">Country</label>
                                    <input class="form-control" type="text" id="lcountry" name="lcountry" placeholder="Enter Country" value="{{ $ilocation->lcountry }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="lpostalcode">Postal Code</label>
                                    <input class="form-control" type="text" id="lpostalcode" name="lpostalcode" placeholder="Enter Postal Code" value="{{ $ilocation->lpostalcode }}">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="ltelephone">Telephone</label>
                                    <input class="form-control" type="text" id="ltelephone" name="ltelephone" placeholder="Enter Telephone" value="{{ $ilocation->ltelephone }}">
                                </div>
                                <br>
                                <div class="form-check">
                                    <label class="form-check-label">
                                      <input type="checkbox" class="form-check-input" value="lship2location" name="lship2location" {{ $ilocation->lship2location == 'lship2location' ? 'checked' : '' }}>Ship-to-Location
                                    </label>
                                </div>
                                <br>
                                <div class="form-check">
                                    <label class="form-check-label">
                                      <input type="checkbox" class="form-check-input" value="lship2site" name="lship2site" {{ $ilocation->lship2site == 'lship2site' ? 'checked' : '' }}>Ship-to-Site
                                    </label>
                                </div>
                                <br>
                                <div class="form-check">
                                    <label class="form-check-label">
                                      <input type="checkbox" class="form-check-input" value="lbill2ship" name="lbill2ship" {{ $ilocation->lbill2ship == 'lbill2ship' ? 'checked' : '' }}>Bill-to-Site
                                    </label>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save Inventory Information</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
@endsection
