<!doctype html>
<html class="no-js') }}" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Item Information</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @include('backend.layouts.partials.style');
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>

</head>

<body>

    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->


        <!-- main content area start -->
        <div class="main-content-inner">
            <div class="row">
                <!-- data table start -->
                <div class="col-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Edit Item {{ $item->itemdes }}</h4>
                                @include('backend.layouts.partials.messages')

                                <form action="{{ route('items.update', $item->id) }}" method="POST">
                                    {{-- @method('PUT') --}}
                                    @csrf

                                    <div class="form-row">
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="invcode">Inventory Code</label>
                                            <select name="invcode" id="invcode" class="form-control" value="{{ $item->invcode }}">
                                                <!-- <option selected>Choose...</option> -->
                                                @foreach ($inventoryorgs as $inventoryorg)
                                                    <option value="{{ $inventoryorg->invcode }}">{{ $inventoryorg->invcode }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="invname">Inventory Name</label>
                                            <select name="invname" id="invname" class="form-control" value="{{ $item->invname }}">
                                                <!-- <option selected>Choose...</option> -->
                                                @foreach ($inventoryorgs as $inventoryorg)
                                                    <option value="{{ $inventoryorg->invname }}">{{ $inventoryorg->invname }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="itemcode">Item Code</label>
                                            <input type="text" class="form-control" id="itemcode" name="itemcode" placeholder="Enter Item Code"  value="{{ $item->itemcode }}">
                                        </div>

                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="itemdes">Item Description</label>
                                            <input type="text" class="form-control" id="itemdes" name="itemdes" placeholder="Enter Item Description" value="{{ $item->itemdes }}">
                                        </div>

                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="measure">Unit of Measure</label>
                                            <input type="text" class="form-control" id="measure" name="measure" placeholder="Enter Unit of Measure" value="{{ $item->measure }}">
                                        </div>

                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="lot">Lot Starting Number</label>
                                            <input type="text" class="form-control" id="lot" name="lot" placeholder="Enter Lot Starting Number" value="{{ $item->lot }}">
                                        </div>



                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="minitem">Minimum Quantity</label>
                                            <input type="text" class="form-control" id="minitem" name="minitem" placeholder="Enter Minimum Quantity" value="{{ $item->minitem }}">
                                        </div>

                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="maxitem">Maximun Quantity</label>
                                            <input type="text" class="form-control" id="maxitem" name="maxitem" placeholder="Enter Maximun Quantity" value="{{ $item->maxitem }}">
                                        </div>

                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="mindays">Minimum Days of Supply</label>
                                            <input type="text" class="form-control" id="mindays" name="mindays" placeholder="Enter Minimum Days of Supply" value="{{ $item->mindays }}">
                                        </div>

                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="maxdays">Maximun Days of Supply</label>
                                            <input type="text" class="form-control" id="maxdays" name="maxdays" placeholder="Enter Maximun Days of Supply" value="{{ $item->maxdays }}">
                                        </div>

                                    </div>

                                    <div class="form-check col-md-6 col-sm-12">
                                        <label for="">Item Status</label><br>
                                        <label class="form-check-label col-md-6 col-sm-12">
                                          <input type="checkbox" class="form-check-input" value="itemstatus" name="itemstatus" {{ $item->itemstatus == 'itemstatus' ? 'checked' : '' }}>Active
                                        </label>
                                    </div>
                                    <br>

                                    <div class="form-group col-md-6 col-sm-12">
                                        <label for="makebuy">Make or Buy</label>
                                        <select name="makebuy" id="makebuy" style="width: 560px; height: 45px;">
                                            <option value="{{ $item->makebuy }}">{{ $item->makebuy }}</option>
                                            <option value="Make">Make</option>
                                            <option value="Buy">Buy</option>
                                        </select>
                                    </div>

                                    <div class="form-check">
                                        <label class="form-check-label">
                                          <input type="checkbox" class="form-check-input" value="invitem" name="invitem">Inventory Item
                                        </label>
                                    </div>
                                    <br>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                          <input type="checkbox" class="form-check-input" value="stockable" name="stockable" {{ $item->stockable == 'stockable' ? 'checked' : '' }}> Stockable
                                        </label>
                                    </div>
                                    <br>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                          <input type="checkbox" class="form-check-input" value="reservable" name="reservable" {{ $item->reservable == 'reservable' ? 'checked' : '' }}>Reservable
                                        </label>
                                    </div>
                                    <br>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                          <input type="checkbox" class="form-check-input" value="transactable" name="transactable" {{ $item->transactable == 'transactable' ? 'checked' : '' }}>Transactable
                                        </label>
                                    </div>
                                    <br>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                          <input type="checkbox" class="form-check-input" value="purchaseable" name="purchaseable" {{ $item->purchaseable == 'purchaseable' ? 'checked' : '' }}>Purchaseable
                                        </label>
                                    </div>
                                    <br>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                          <input type="checkbox" class="form-check-input" value="customerordered" name="customerordered" {{ $item->customerordered == 'customerordered' ? 'checked' : '' }}>Customer Ordered
                                        </label>
                                    </div>
                                    <br>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                          <input type="checkbox" class="form-check-input" value="internalordered" name="internalordered" {{ $item->internalordered == 'internalordered' ? 'checked' : '' }}>Internal Ordered
                                        </label>
                                    </div>
                                    <br>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                          <input type="checkbox" class="form-check-input" value="shippableordered" name="shippableordered" {{ $item->shippableordered == 'shippableordered' ? 'checked' : '' }}>Shippable Ordered
                                        </label>
                                    </div>
                                    <br>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                          <input type="checkbox" class="form-check-input" value="returnable" name="returnable" {{ $item->returnable == 'returnable' ? 'checked' : '' }}>Returnable
                                        </label>
                                    </div>

                                    <div class="hidden-print">
                                        <div class="pull-right">
                                            <a href="#" onclick="window.print()" class="btn btn-primary mt-4 pr-4 pl-4"><i class="fa fa-print">Print</i></a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- data table end -->

                </div>
            </div>


        </div>


        <!-- main content area end -->

        @include('backend.layouts.partials.footer');



    <!-- page container area end -->

    @include('backend.layouts.partials.offsets');

    @include('backend.layouts.partials.scripts');

    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.select2').select2();
        })
    </script>

</body>

</html>
