@extends('backend.layouts.master')

@section('title')
Master Items - Admin Panel
@endsection

@section('styles')
    <!-- Start datatable css -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Master Items</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><span>All Master Items</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title float-left">Master Items List</h4>
                    <p class="float-right mb-2">
                    @if (Auth::guard('admin')->user()->can('item.create'))
                        <a class="btn btn-primary text-white" href="{{ route('items.create') }}">Add New Item</a>
                        @endif
                    </p>
                    <div class="clearfix"></div>
                    <div class="data-tables">
                        @include('backend.layouts.partials.messages')
                        <table id="dataTable" class="text-center">
                            <thead class="bg-light text-capitalize">
                                <tr>
                                    <th>Inventory Code</th>
                                    <th>Inventory Name</th>
                                    <th>Item Code</th>
                                    <th>Item Description</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>
                               @foreach ($items as $item)
                               <tr>
                                    <td>{{ $item->invcode }}</td>
                                    <td>{{ $item->invname }}</td>
                                    <td>{{ $item->itemcode }}</td>
                                    <td>{{ $item->itemdes }}</td>
                                    <td>
                                        <a class="btn btn-info text-white" href="{{ route('items.show', $item->id) }}">View</a>

                                        @if (Auth::guard('admin')->user()->can('item.edit'))
                                        <a class="btn btn-success text-white" href="{{ route('items.edit', $item->id) }}">Edit</a>
                                        @endif

                                        @if (Auth::guard('admin')->user()->can('item.delete'))
                                        <a class="btn btn-danger text-white" href="{{ route('items.delete', $item->id) }}"
                                        onclick="event.preventDefault(); document.getElementById('delete-form-{{ $item->id }}').submit();">
                                            Delete
                                        </a>

                                        <form id="delete-form-{{ $item->id }}" action="{{ route('items.delete', $item->id) }}" method="GET" style="display: none;">
                                            @method('DELETE')
                                            @csrf
                                        </form>
                                        @endif
                                    </td>
                                </tr>
                               @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
@endsection


@section('scripts')
     <!-- Start datatable js -->
     <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
     <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
     <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
     {{-- <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script> --}}
     <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>

     <script>
         /*================================
        datatable active
        ==================================*/
        if ($('#dataTable').length) {
            $('#dataTable').DataTable({
                responsive: true
            });
        }
     </script>
@endsection

