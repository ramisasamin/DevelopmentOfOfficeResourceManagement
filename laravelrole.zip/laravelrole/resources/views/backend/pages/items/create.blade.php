@extends('backend.layouts.master')

@section('title')
Item Create - Admin Panel
@endsection

@section('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Item Creation Form</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><a href="{{ route('items.index') }}">All Items</a></li>
                    <li><span>Create Item</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Create New Item</h4>
                    @include('backend.layouts.partials.messages')

                    <form action="{{ route('items.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="invcode">Inventory Code</label>
                                <select name="invcode" id="invcode" class="form-control">
                                    <option selected>Choose...</option>
                                    @foreach ($inventoryorgs as $inventoryorg)
                                        <option value="{{ $inventoryorg->invcode }}">{{ $inventoryorg->invcode }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="invname">Inventory Name</label>
                                <input type="text" class="form-control" id="invname" name="invname" placeholder="Enter Inventory Name">
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="itemcode">Item Code</label>
                                <input type="text" class="form-control" id="itemcode" name="itemcode" placeholder="Enter Item Code">
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="itemdes">Item Description</label>
                                <input type="text" class="form-control" id="itemdes" name="itemdes" placeholder="Enter Item Description">
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="measure">Unit of Measure</label>
                                <input type="text" class="form-control" id="measure" name="measure" placeholder="Enter Unit of Measure">
                            </div>

                            {{-- <div class="form-group col-md-6 col-sm-12">
                                <label for="itemtype">Item Type</label>
                                <input type="text" class="form-control" id="itemtype" name="itemdes" placeholder="Enter Item Type">
                            </div> --}}

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="lot">Lot Starting Number</label>
                                <input type="text" class="form-control" id="lot" name="lot" placeholder="Enter Lot Starting Number">
                            </div>



                            <div class="form-group col-md-6 col-sm-12">
                                <label for="minitem">Minimum Quantity</label>
                                <input type="text" class="form-control" id="minitem" name="minitem" placeholder="Enter Minimum Quantity">
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="maxitem">Maximun Quantity</label>
                                <input type="text" class="form-control" id="maxitem" name="maxitem" placeholder="Enter Maximun Quantity">
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="mindays">Minimum Days of Supply</label>
                                <input type="text" class="form-control" id="mindays" name="mindays" placeholder="Enter Minimum Days of Supply">
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="maxdays">Maximun Days of Supply</label>
                                <input type="text" class="form-control" id="maxdays" name="maxdays" placeholder="Enter Maximun Days of Supply">
                            </div>

                        </div>
                        <div class="form-check col-md-6 col-sm-12">
                            <label for="">Item Status</label><br>
                            <label class="form-check-label col-md-6 col-sm-12">
                              <input type="checkbox" class="form-check-input" value="itemstatus" name="itemstatus">Active
                            </label>
                        </div>
                        <br>

                        <div class="form-group col-md-6 col-sm-12">
                            <label for="makebuy">Make or Buy</label>
                            <select name="makebuy" id="makebuy" style="width: 560px; height: 45px;">
                                <option value="0" disabled="true" selected="true">-Select-</option>
                                <option value="Make">Make</option>
                                <option value="Buy">Buy</option>
                            </select>
                        </div>

                        <div class="form-check">
                            <label class="form-check-label">
                              <input type="checkbox" class="form-check-input" value="invitem" name="invitem">Inventory Item
                            </label>
                        </div>
                        <br>
                        <div class="form-check">
                            <label class="form-check-label">
                              <input type="checkbox" class="form-check-input" value="stockable" name="stockable">Stockable
                            </label>
                        </div>
                        <br>
                        <div class="form-check">
                            <label class="form-check-label">
                              <input type="checkbox" class="form-check-input" value="reservable" name="reservable">Reservable
                            </label>
                        </div>
                        <br>
                        <div class="form-check">
                            <label class="form-check-label">
                              <input type="checkbox" class="form-check-input" value="transactable" name="transactable">Transactable
                            </label>
                        </div>
                        <br>
                        <div class="form-check">
                            <label class="form-check-label">
                              <input type="checkbox" class="form-check-input" value="purchaseable" name="purchaseable">Purchaseable
                            </label>
                        </div>
                        <br>
                        <div class="form-check">
                            <label class="form-check-label">
                              <input type="checkbox" class="form-check-input" value="customerordered" name="customerordered">Customer Ordered
                            </label>
                        </div>
                        <br>
                        <div class="form-check">
                            <label class="form-check-label">
                              <input type="checkbox" class="form-check-input" value="internalordered" name="internalordered">Internal Ordered
                            </label>
                        </div>
                        <br>
                        <div class="form-check">
                            <label class="form-check-label">
                              <input type="checkbox" class="form-check-input" value="shippableordered" name="shippableordered">Shippable Ordered
                            </label>
                        </div>
                        <br>
                        <div class="form-check">
                            <label class="form-check-label">
                              <input type="checkbox" class="form-check-input" value="returnable" name="returnable">Returnable
                            </label>
                        </div>


                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save Item</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>

<script>
    /*================================
   datatable active
   ==================================*/
   if ($('#dataTable').length) {
       $('#dataTable').DataTable({
           responsive: true
       });
   }
   $('#invcode').on('input', function(e){
            var invcode_ = $('#invcode option:selected').val();
            $.ajax({
                type:"GET",
                url:"{{ url('onhands/getinv') }}",
                data:{
                    invcode: invcode_
                },
                success: function(data){
                    if(data){
                        $('#invname').val(data);
                    }else{
                        $('#invname').val('');
                    }
                }
            });

        });
</script>

@endsection
