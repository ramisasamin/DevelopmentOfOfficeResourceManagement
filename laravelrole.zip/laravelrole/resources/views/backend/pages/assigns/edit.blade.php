@extends('backend.layouts.master')

@section('title')
Assigned Items - Admin Panel
@endsection

@section('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Assigned Item Edit<</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><a href="{{ route('assigns.index') }}">All Assigned Items</a></li>
                    <li><span>Edit Assigned Items</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit Assigned Items - {{ $assign->eid }}</h4>
                    @include('backend.layouts.partials.messages')

                    <form action="{{ route('assigns.update', $assign->id) }}" method="POST">
                        {{-- @method('PUT') --}}
                        @csrf

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="eid">Employee ID</label>
                                <select name="eid" id="eid" class="form-control">
                                    <option value="0" disabled="true" selected="true">-Select-</option>
                                    @foreach ($users as $user)
                                        <option value="{{ $user->eid }}">{{ $user->eid }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="name">Employee Name</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Enter Employee Name">  
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="itemcode">Item Code</label>
                                <select name="itemcode" id="itemcode" class="form-control">
                                    <option value="0" disabled="true" selected="true">-Select-</option>
                                    @foreach ($items as $item)
                                        <option value="{{ $item->itemcode }}">{{ $item->itemcode }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="itemdes">Item Description</label>
                                <input type="text" class="form-control" id="itemdes" name="itemdes" placeholder="Enter Item Description">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="invcode">Inventory Code</label>
                                <select name="invcode" id="invcode" class="form-control">
                                    <option value="0" disabled="true" selected="true">-Select-</option>
                                    @foreach ($inventoryorgs as $inventoryorg)
                                        <option value="{{ $inventoryorg->invcode }}">{{ $inventoryorg->invcode }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="invname">Inventory Name</label>
                                <input type="text" class="form-control" id="invname" name="invname" placeholder="Enter Inventory Name">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="assigndate">Assign Date</label>
                                <input class="form-control" type="date" id="assigndate" name="assigndate">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="noitem">Item Status</label><br>
                                <select name="noitem" id="noitem" style="width: 560px; height: 45px;">
                                    <option value="new">New</option>
                                    <option value="old">Old</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="remarks">Remarks</label>
                                <input type="text" class="form-control" id="remarks" name="remarks" placeholder="Enter Remarks">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="warranty">Warranty Last Date</label>
                                <input class="form-control" type="date" id="warranty" name="warranty">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save Assigned Item Information</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
<script>
    /*================================
   datatable active
   ==================================*/
   if ($('#dataTable').length) {
       $('#dataTable').DataTable({
           responsive: true
       });
   }
   $('#eid').on('input', function(e){
       var eid_ = $('#eid option:selected').val();
       $.ajax({
           type:"GET",
           url:"{{ url('assigns/getemp') }}",
           data:{
            eid: eid_
           },
           success: function(data){
               if(data){
                   $('#name').val(data);
               }else{
                   $('#name').val('');
               }
           }
       });

   });
   $('#invcode').on('input', function(e){
       var invcode_ = $('#invcode option:selected').val();
       $.ajax({
           type:"GET",
           url:"{{ url('assigns/getinv') }}",
           data:{
               invcode: invcode_
           },
           success: function(data){
               if(data){
                   $('#invname').val(data);
               }else{
                   $('#invname').val('');
               }
           }
       });

   });
   $('#itemcode').on('input', function(e){
      var itemcode_ = $('#itemcode option:selected').val();
      $.ajax({
          type:"GET",
          url:"{{ url('assigns/getitem') }}",
          data:{
           itemcode: itemcode_
          },
          success: function(data){
              if(data){
                  $('#itemdes').val(data);
              }else{
                  $('#itemdes').val('');
              }
          }
      });

  });
</script>
@endsection
