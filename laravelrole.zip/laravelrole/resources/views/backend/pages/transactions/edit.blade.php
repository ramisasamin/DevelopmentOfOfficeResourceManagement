@extends('backend.layouts.master')

@section('title')
Miscellaneous Edit - Admin Panel
@endsection

@section('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Miscellaneous Edit</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><a href="{{ route('transactions.index') }}">All Transactions</a></li>
                    <li><span>Edit Miscellaneous</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit Miscellaneous - {{ $transaction->jobname }}</h4>
                    @include('backend.layouts.partials.messages')

                    <form action="{{ route('transactions.update', $transaction->id) }}" method="POST">
                        {{-- @method('PUT') --}}
                        @csrf

                        <div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="transdate">Miscellaneous Date</label>
                                <input class="form-control" type="date" id="transdate" name="transdate" value="{{ $transaction->transdate}}">
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="transtype">Miscellaneous Type</label>
                                    <select name="transtype" id="transtype" value="{{ $transaction->transtype}}" style="width: 560px; height: 45px;">
                                        <option value="{{ $transaction->transtype }}">{{ $transaction->transtype }}</option>
                                        <option value="miscellaneousissue">Miscellaneous Issue</option>
                                        <option value="miscellaneousreceipt">Miscellaneous Receipt</option>
                                    </select>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="itemcode">Item code</label>
                                    <select name="itemcode" id="itemcode" class="form-control"  value="{{ $transaction->itemcode}}">
                                        <!-- <option selected>Choose...</option> -->
                                        @foreach ($items as $item)
                                            <option value="{{ $item->itemcode }}">{{ $item->itemcode }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="itemdes">Item Description</label>
                                    <input type="text" class="form-control" id="itemdes" name="itemdes" placeholder="Enter Item Description" value="{{ $transaction->itemdes}}">
                                </div>
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="quantity">Quantity</label>
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="invcode">Inventory Code</label>
                                    <select name="invcode" id="invcode" class="form-control" value="{{ $transaction->invcode}}">
                                        <!-- <option selected>Choose...</option> -->
                                        @foreach ($inventoryorgs as $inventoryorg)
                                            <option value="{{ $inventoryorg->invcode }}">{{ $inventoryorg->invcode }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="invname">Inventory Name</label>
                                    <select name="invname" id="invname" class="form-control" value="{{ $transaction->invname}}">
                                        <!-- <option selected>Choose...</option> -->
                                        @foreach ($inventoryorgs as $inventoryorg)
                                            <option value="{{ $inventoryorg->invname }}">{{ $inventoryorg->invname }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                        </div>

                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save Miscellaneous Information</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
@endsection
