@extends('backend.layouts.master')

@section('title')
Miscellany - Admin Panel
@endsection

@section('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Miscellaneous Create</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><a href="{{ route('transactions.index') }}">All Miscellany</a></li>
                    <li><span>Create Miscellaneous</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Create New Miscellaneous</h4>
                    @include('backend.layouts.partials.messages')

                    <form action="{{ route('transactions.store') }}" method="POST">
                        @csrf
                        <div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="transdate">Miscellaneous Date</label>
                                <input class="form-control" type="date" id="transdate" name="transdate">
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="transtype">Miscellaneous Type</label>
                                    <select name="transtype" id="transtype" style="width: 560px; height: 45px;">
                                        <option value="miscellaneousissue">Miscellaneous Issue</option>
                                        <option value="miscellaneousreceipt">Miscellaneous Receipt</option>
                                    </select>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="itemcode">Item code</label>
                                    <select name="itemcode" id="itemcode" class="form-control">
                                        <option selected>Choose...</option>
                                        @foreach ($items as $item)
                                            <option value="{{ $item->itemcode }}">{{ $item->itemcode }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="itemdes">Item Description</label>
                                    <input type="text" class="form-control" id="itemdes" name="itemdes" placeholder="Enter Item Description">
                                </div>
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="quantity">Quantity</label>
                                <input type="text" class="form-control" id="quantity" name="quantity" placeholder="Enter Quantity">
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="invcode">Inventory Code</label>
                                    <select name="invcode" id="invcode" class="form-control">
                                        <option selected>Choose...</option>
                                        @foreach ($inventoryorgs as $inventoryorg)
                                            <option value="{{ $inventoryorg->invcode }}">{{ $inventoryorg->invcode }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="invname">Inventory Name</label>
                                    <input type="text" class="form-control" id="invname" name="invname"  placeholder="Enter Inventory Name">
                                </div>
                            </div>

                        </div>

                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save Miscellaneous</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
<script>
    /*================================
   datatable active
   ==================================*/
   if ($('#dataTable').length) {
       $('#dataTable').DataTable({
           responsive: true
       });
   }
   $('#invcode').on('input', function(e){
       var invcode_ = $('#invcode option:selected').val();
       $.ajax({
           type:"GET",
           url:"{{ url('transactions/getinv') }}",
           data:{
               invcode: invcode_
           },
           success: function(data){
               if(data){
                   $('#invname').val(data);
               }else{
                   $('#invname').val('');
               }
           }
       });

   });
   $('#itemcode').on('input', function(e){
      var itemcode_ = $('#itemcode option:selected').val();
      $.ajax({
          type:"GET",
          url:"{{ url('transactions/getitem') }}",
          data:{
           itemcode: itemcode_
          },
          success: function(data){
              if(data){
                  $('#itemdes').val(data);
              }else{
                  $('#itemdes').val('');
              }
          }
      });

  });
</script>
@endsection
