<?php $__env->startSection('title'); ?>
Inventory Location Create - Admin Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Inventory Location Creation Form</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('ilocations.index')); ?>">All Inventory Locations</a></li>
                    <li><span>Create Inventory Location</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            <?php echo $__env->make('backend.layouts.partials.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Create New Role</h4>
                    <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <form action="<?php echo e(route('ilocations.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <div class="form-group col-md-12">
                                    <label for="lname">Location Name</label>
                                    <input class="form-control" type="text" id="lname" name="lname" placeholder="Enter Location Name">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="ldescription">Description</label>
                                    <input class="form-control" type="text" id="ldescription" name="ldescription" placeholder="Enter Description">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="linactivedate">Inactive Date</label>
                                    <input class="form-control" type="text" id="linactivedate" name="linactivedate" placeholder="Enter Inactive Date">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="ladd">Address</label>
                                    <input class="form-control" type="text" id="ladd" name="ladd" placeholder="Enter Address">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="lcity">City</label>
                                    <input class="form-control" type="text" id="lcity" name="lcity" placeholder="Enter City">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="lregion">Region</label>
                                    <input class="form-control" type="text" id="lregion" name="lregion" placeholder="Enter Region">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="lcountry">Country</label>
                                    <input class="form-control" type="text" id="lcountry" name="lcountry" placeholder="Enter Country">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="lpostalcode">Postal Code</label>
                                    <input class="form-control" type="text" id="lpostalcode" name="lpostalcode" placeholder="Enter Postal Code">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="ltelephone">Telephone</label>
                                    <input class="form-control" type="text" id="ltelephone" name="ltelephone" placeholder="Enter Telephone">
                                </div>
                                <br>
                                <div class="form-check">
                                    <label class="form-check-label">
                                      <input type="checkbox" class="form-check-input" value="lship2location" name="lship2location">Ship-to-Location
                                    </label>
                                </div>
                                <br>
                                <div class="form-check">
                                    <label class="form-check-label">
                                      <input type="checkbox" class="form-check-input" value="lship2site" name="lship2site">Ship-to-Site
                                    </label>
                                </div>
                                <br>
                                <div class="form-check">
                                    <label class="form-check-label">
                                      <input type="checkbox" class="form-check-input" value="lbill2ship" name="lbill2ship">Bill-to-Site
                                    </label>
                                </div>
                            </div>
                        </div>


                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save Inventory Location</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelrole\resources\views\backend\pages\ilocations\create.blade.php ENDPATH**/ ?>