<?php $__env->startSection('title'); ?>
Employee Create - Admin Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Employee Creation Form</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('users.index')); ?>">All Users</a></li>
                    <li><span>Create User</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            <?php echo $__env->make('backend.layouts.partials.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Create New Role</h4>
                    <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <form action="<?php echo e(route('users.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-row">
                            <div class="form-group col-md-2 col-sm-12">
                                <label for="titlename">Title</label>
                                <select name="titlename" id="titlename" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($title->titlename); ?>"><?php echo e($title->titlename); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="name">First Name</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Enter First Name">
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="namel">Last name</label>
                                <input type="text" class="form-control" id="namel" name="namel" placeholder="Enter Last Name">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="fname">Father's Name</label>
                                <input type="text" class="form-control" id="fname" name="fname" placeholder="Enter Father's Name">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="fno">Father's Phone Number</label>
                                <input type="text" class="form-control" id="fno" name="fno" placeholder="Enter Father's Number">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="mname">Mother's Name</label>
                                <input type="text" class="form-control" id="mname" name="mname" placeholder="Enter Mother's Name">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="mno">Mother's Phone Number</label>
                                <input type="text" class="form-control" id="mno" name="mno" placeholder="Enter Mother's Number">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="gendername">Gender</label>
                                <select name="gendername" id="gendername" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($gender->gendername); ?>"><?php echo e($gender->gendername); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="systemtype">Emploment Type</label>
                                <select name="systemtype" id="systemtype" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $persontypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ptype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ptype->systemtype); ?>"><?php echo e($ptype->systemtype); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="eid">Office ID</label>
                                <input type="text" class="form-control" id="eid" name="eid" placeholder="Enter ID">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="nid">NID</label>
                                <input type="text" class="form-control" id="nid" name="nid" placeholder="Enter NID">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-2 col-sm-12">
                                <br><label>Effective Dates: </label>
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="start">From</label>
                                <input class="form-control" type="date" id="start" name="start">
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="end">To</label>
                                <input class="form-control" type="date" id="end" name="end">
                            </div>
                        </div>

                        <hr>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <h5 style="color: black">Personal Information</h5>
                                <br>
                                <div class="form-group col-md-12">
                                    <label for="bd">Date of Birth</label>
                                    <input class="form-control" type="date" id="bd" name="bd" placeholder="Enter Date of Birth">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="place">Place of Birth</label>
                                    <input class="form-control" type="text" id="place" name="place" placeholder="Enter Place of Birth">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="maritalstatus">Marital Status</label>
                                    <select name="maritalstatus" id="maritalstatus" class="form-control">
                                        <option selected>Choose...</option>
                                        <?php $__currentLoopData = $maritals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($marital->maritalstatus); ?>"><?php echo e($marital->maritalstatus); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="nationalityname">Nationality</label>
                                    <select name="nationalityname" id="nationalityname" class="form-control">
                                        <option selected>Choose...</option>
                                        <?php $__currentLoopData = $nationalities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($nationality->nationalityname); ?>"><?php echo e($nationality->nationalityname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-12">
                                    <label>Upload Picture</label>
                                    <input type="file" name="image" class="form-control" required onchange="readURL(this);">
                                </div>
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <h5 style="color: black">Office Details</h5>
                                <br>
                                <div class="form-group col-md-12">
                                    <label for="office">Office</label>
                                    <input type="text" class="form-control" id="office" name="office" placeholder="Enter Office">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="address">Address</label>
                                    <input type="text" class="form-control" id="address" name="address" placeholder="Enter Address">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="mail">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="ono">Office Mobile Number</label>
                                    <input type="text" class="form-control" id="ono" name="ono" placeholder="Enter Phone Number">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="pno">Personal Mobile Number</label>
                                    <input type="text" class="form-control" id="pno" name="pno" placeholder="Enter Phone Number">
                                </div>
                            </div>
                        </div>

                        <hr>
                        <h5 style="color: black">Assignment</h5>
                        <br>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="shortname">Organization</label>
                                <select name="shortname" id="shortname" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unit->shortname); ?>"><?php echo e($unit->shortname); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="statusassign">Status</label>
                                <select name="statusassign" id="statusassign" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($status->statusassign); ?>"><?php echo e($status->statusassign); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="jobname">Job Position</label>
                                <select name="jobname" id="jobname" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($job->jobname); ?>"><?php echo e($job->jobname); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="sscale">Salary Scale</label>
                                <input type="text" class="form-control" id="sscale" name="sscale" placeholder="Enter Salary Scale">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="gradecode">Grade</label>
                                <select name="gradecode" id="gradecode" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($grade->gradecode); ?>"><?php echo e($grade->gradecode); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="supname">Supervisor's Name</label>
                                <input type="text" class="form-control" id="supname" name="supname" placeholder="Enter Supervisor's Name">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="locationcode">Location</label>
                                <select name="locationcode" id="locationcode" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($location->locationcode); ?>"><?php echo e($location->locationcode); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="supno">Supervisor's Number</label>
                                <input type="text" class="form-control" id="supno" name="supno" placeholder="Enter Supervisor's Number">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="assignno">Assignment Number</label>
                                <input type="text" class="form-control" id="assignno" name="assignno" placeholder="Enter Assignment Number">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="period">Probation Period Length</label>
                                <input type="text" class="form-control" id="period" name="period" placeholder="Enter Period Length">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="categoryname">Assignment Category</label>
                                <select name="categoryname" id="categoryname" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->categoryname); ?>"><?php echo e($category->categoryname); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="periodend">Probation Period End</label>
                                <input type="text" class="form-control" id="periodend" name="periodend" placeholder="Enter Period End">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="grp">Group</label>
                                <select class="form-control" id="grp" name="grp">
                                    <option selected>Choose...</option>
                                    <option value="1">PSG</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="notice">Notice Period Length</label>
                                <input type="text" class="form-control" id="notice" name="notice" placeholder="Enter Period Length">
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="positionname">Position</label>
                                <select name="positionname" id="positionname" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($position->positionname); ?>"><?php echo e($position->positionname); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="whour">Working Hours</label>
                                <input type="text" class="form-control" id="whour" name="whour" placeholder="Enter Working Hours">
                            </div>
                        </div>

                        <hr>
                        <h5 style="color: black">Salary Determination</h5>
                        <br>

                        <div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="shr">Salary/Hour</label>
                                <input type="text" class="form-control" id="shr" name="shr" placeholder="Enter Amount">
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-2 col-sm-12">
                                    <br><label>Working Hours</label>
                                </div>
                                <div class="form-group col-md-5 col-sm-12">
                                    <input class="form-control" type="time" id="stime" name="stime">
                                </div>
                                <div class="form-group col-md-5 col-sm-12">
                                    <input class="form-control" type="time" id="etime" name="etime">
                                </div>
                            </div>
                            <br>
                            <div class="form-check">
                                <label class="form-check-label">
                                  <input type="checkbox" class="form-check-input" value="checkbox" name="checkbox">Work from Home
                                </label>
                            </div>
                            <br>
                            <div class="form-row">
                                <div class="form-group col-md-2 col-sm-12">
                                    <br><label>Effective Dates</label>
                                </div>
                                <div class="form-group col-md-5 col-sm-12">
                                    <input class="form-control" type="date" id="datestart" name="datestart">
                                </div>
                                <div class="form-group col-md-5 col-sm-12">
                                    <input class="form-control" type="date" id="dateend" name="dateend">
                                </div>
                            </div>
                        </div>



                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save User</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelrole\resources\views\backend\pages\users\create.blade.php ENDPATH**/ ?>