 <!-- sidebar menu area start -->

 <?php
 $usr = Auth::guard('admin')->user();
?>

 <div class="sidebar-menu">
    <div class="sidebar-header">
        <div class="logo">
            <a href="<?php echo e(route('admin.dashboard')); ?>">
                <h5 class="text-white">Office Resource Management System</h5>
            </a>
        </div>

    </div>
    <div class="main-menu">
        <div class="menu-inner">
            <nav>
                <ul class="metismenu" id="menu">

                    <?php if($usr->can('dashboard.view')): ?>
                    <li class="active">
                        <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>dashboard</span></a>
                        <ul class="collapse">
                            <li class="<?php echo e(Route::is('admin.dashboard') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.dashboard')); ?>">Overview Board</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if($usr->can('role.create') || $usr->can('role.view') ||  $usr->can('role.edit') ||  $usr->can('role.delete')): ?>
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-tasks"></i><span>
                            Roles & Permissions
                        </span></a>
                        <ul class="collapse <?php echo e(Route::is('roles.create') || Route::is('roles.index') || Route::is('roles.edit') || Route::is('roles.show') ? 'in' : ''); ?>">
                            <?php if($usr->can('role.view')): ?>
                                <li class="<?php echo e(Route::is('roles.index')  || Route::is('roles.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('roles.index')); ?>">All Roles</a></li>
                            <?php endif; ?>
                            <?php if($usr->can('role.create')): ?>
                                <li class="<?php echo e(Route::is('roles.create')  ? 'active' : ''); ?>"><a href="<?php echo e(route('roles.create')); ?>">Create Role</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if($usr->can('admin.create') || $usr->can('admin.view') ||  $usr->can('admin.edit') ||  $usr->can('admin.delete')): ?>
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i><span>
                            Admins
                        </span></a>
                        <ul class="collapse <?php echo e(Route::is('admins.create') || Route::is('admins.index') || Route::is('admins.edit') || Route::is('admins.show') ? 'in' : ''); ?>">

                            <?php if($usr->can('admin.view')): ?>
                                <li class="<?php echo e(Route::is('admins.index')  || Route::is('admins.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('admins.index')); ?>">All Admins</a></li>
                            <?php endif; ?>

                            <?php if($usr->can('admin.create')): ?>
                                <li class="<?php echo e(Route::is('admins.create')  ? 'active' : ''); ?>"><a href="<?php echo e(route('admins.create')); ?>">Create Admin</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if($usr->can('employee.create') || $usr->can('employee.view') ||  $usr->can('employee.edit') ||  $usr->can('employee.delete')): ?>
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i><span>
                            Employees
                        </span></a>
                        <ul class="collapse <?php echo e(Route::is('users.create') || Route::is('users.index') || Route::is('users.edit') || Route::is('users.show') ? 'in' : ''); ?>">
                            <?php if($usr->can('employee.view')): ?>
                            <li class="<?php echo e(Route::is('users.index')  || Route::is('users.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('users.index')); ?>">All Employees</a></li>
                            <?php endif; ?>
                            <?php if($usr->can('employee.create')): ?>
                            <li class="<?php echo e(Route::is('users.create')  ? 'active' : ''); ?>"><a href="<?php echo e(route('users.create')); ?>">Add Employee</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if($usr->can('manage.create') || $usr->can('manage.view') ||  $usr->can('manage.edit') ||  $usr->can('manage.delete')): ?>
                    <li>
                    <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i>
                        <span>
                            HRMS Management
                        </span>
                    </a>
                        <ul class="collapse <?php echo e(Route::is('units.create') || Route::is('units.index') || Route::is('units.edit') || Route::is('units.show') ||
                        Route::is('jobs.create')  || Route::is('jobs.index')  || Route::is('jobs.edit') || Route::is('jobs.show') ||
                        Route::is('positions.create')  || Route::is('positions.index') || Route::is('positions.edit') || Route::is('positions.show') ||
                        Route::is('grades.create')  || Route::is('grades.index') || Route::is('grades.edit') || Route::is('grades.show') ||
                        Route::is('categories.create')  || Route::is('categories.index') || Route::is('categories.edit') || Route::is('categories.show') ||
                        Route::is('locations.create')  || Route::is('locations.index') || Route::is('locations.edit') || Route::is('locations.show') ||
                        Route::is('nationalities.create')  || Route::is('nationalities.index') || Route::is('nationalities.edit') || Route::is('nationalities.show') ||
                        Route::is('legals.create')  || Route::is('legals.index') || Route::is('legals.edit') || Route::is('legals.show') ||
                        Route::is('ledgers.create')  || Route::is('ledgers.index') || Route::is('ledgers.edit') || Route::is('ledgers.show')
                        ? 'in' : ''); ?>">
                        <?php if($usr->can('manage.view')): ?>

                            <li class="<?php echo e(Route::is('units.index')  || Route::is('units.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('units.index')); ?>">Organizations</a></li>
                            <li class="<?php echo e(Route::is('jobs.index')  || Route::is('jobs.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('jobs.index')); ?>">Job</a></li>
                            <li class="<?php echo e(Route::is('positions.index')  || Route::is('positions.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('positions.index')); ?>">Position</a></li>
                            <li class="<?php echo e(Route::is('grades.index')  || Route::is('grades.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('grades.index')); ?>">Grade</a></li>
                            <li class="<?php echo e(Route::is('categories.index')  || Route::is('categories.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('categories.index')); ?>">Category</a></li>
                            <li class="<?php echo e(Route::is('locations.index')  || Route::is('locations.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('locations.index')); ?>">Location</a></li>
                            <li class="<?php echo e(Route::is('nationalities.index')  || Route::is('nationalities.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('nationalities.index')); ?>">Nationality</a></li>
                            <li class="<?php echo e(Route::is('legals.index')  || Route::is('legals.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('legals.index')); ?>">Legal Entity</a></li>
                            <li class="<?php echo e(Route::is('ledgers.index')  || Route::is('ledgers.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('ledgers.index')); ?>">Ledger</a></li>

                        <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if($usr->can('invorganization.create') || $usr->can('invorganization.view') ||  $usr->can('invorganization.edit') ||  $usr->can('invorganization.delete') ||
                    $usr->can('invlocation.create') || $usr->can('invlocation.view') ||  $usr->can('invlocation.edit') ||  $usr->can('invlocation.delete') ||
                    $usr->can('invtransaction.create') || $usr->can('invtransaction.view') ||  $usr->can('invtransaction.edit') ||  $usr->can('invtransaction.delete') ||
                    $usr->can('invonhand.view')): ?>
                    <li>
                    <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i>
                        <span>
                            Inventory
                        </span>
                    </a>
                        <ul class="collapse <?php echo e(Route::is('inventoryorgs.create') || Route::is('inventoryorgs.index') || Route::is('inventoryorgs.edit') || Route::is('inventoryorgs.show') ||
                        Route::is('ilocations.create') || Route::is('ilocations.index') || Route::is('ilocations.edit') || Route::is('ilocations.show') ||
                        Route::is('transactions.create') || Route::is('transactions.index') || Route::is('transactions.edit') || Route::is('transactions.show') ||
                        Route::is('onhands.index')
                        ? 'in' : ''); ?>">
                            <?php if($usr->can('invorganization.view')): ?>
                            <li class="<?php echo e(Route::is('inventoryorgs.index')  || Route::is('inventoryorgs.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('inventoryorgs.index')); ?>">Inventory Organization</a></li>
                            <?php endif; ?>
                            <?php if($usr->can('invlocation.view')): ?>
                            <li class="<?php echo e(Route::is('ilocations.index')  || Route::is('ilocations.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('ilocations.index')); ?>">Location</a></li>
                            <?php endif; ?>
                            <?php if($usr->can('invtransaction.view')): ?>
                            <li class="<?php echo e(Route::is('transactions.index')  || Route::is('transactions.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('transactions.index')); ?>">Transaction</a></li>
                            <?php endif; ?>
                            <?php if($usr->can('invonhand.view')): ?>
                            <li class="<?php echo e(Route::is('onhands.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('onhands.index')); ?>">On-hand Availability</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if($usr->can('item.create') || $usr->can('item.view') ||  $usr->can('item.edit') ||  $usr->can('item.delete')): ?>
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i>
                            <span>
                                Item
                            </span>
                        </a>
                            <ul class="collapse <?php echo e(Route::is('items.create') || Route::is('items.index') || Route::is('items.edit') || Route::is('items.show') ? 'in' : ''); ?>">
                                <?php if($usr->can('item.view')): ?>
                                <li class="<?php echo e(Route::is('items.index')  || Route::is('items.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('items.index')); ?>">Master Item</a></li>
                                <?php endif; ?>
                            </ul>
                    </li>
                    <?php endif; ?>

                    <?php if($usr->can('assignitem.create') || $usr->can('assignitem.view') ||  $usr->can('assignitem.edit') ||  $usr->can('assignitem.delete') ||
                    $usr->can('receiveitem.create') || $usr->can('receiveitem.view') ||  $usr->can('receiveitem.edit') ||  $usr->can('receiveitem.delete')): ?>
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-user"></i>
                            <span>
                                Track of Item
                            </span>
                        </a>
                            <ul class="collapse <?php echo e(Route::is('assigns.create') || Route::is('assigns.index') || Route::is('assigns.edit') || Route::is('assigns.show') ||
                            Route::is('receives.create') || Route::is('receives.edit') || Route::is('receives.show') ? 'in' : ''); ?>">
                                <?php if($usr->can('assignitem.view')): ?>
                                <li class="<?php echo e(Route::is('assigns.index')  || Route::is('assigns.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('assigns.index')); ?>">Item Information</a></li>
                                <?php endif; ?>
                                <?php if($usr->can('assignitem.create')): ?>
                                <li class="<?php echo e(Route::is('assigns.create')  ? 'active' : ''); ?>"><a href="<?php echo e(route('assigns.create')); ?>">Assign Item</a></li>
                                <?php endif; ?>
                                <?php if($usr->can('receiveitem.view')): ?>
                                <li class="<?php echo e(Route::is('receives.create')  ? 'active' : ''); ?>"><a href="<?php echo e(route('receives.create')); ?>">Receive Item</a></li>
                                <?php endif; ?>
                            </ul>
                    </li>
                    <?php endif; ?>

                </ul>
            </nav>
        </div>
    </div>
</div>
<!-- sidebar menu area end -->



<?php /**PATH D:\xampp\htdocs\laravelrole\resources\views/backend/layouts/partials/sidebar.blade.php ENDPATH**/ ?>