<!-- header area start -->
<div class="header-area">
    <div style="float: right;"><h3>Partex Star Group</h3></div>
    <div class="row align-items-center">
        <!-- nav and search button -->
        <div class="col-md-4 col-sm-8 clearfix">
            <div class="nav-btn pull-left">
                <span></span>
                <span></span>
                <span></span>
            </div>

            
        </div>
        <!-- profile info & task notification -->
        
    </div>
</div>
<!-- header area end -->
<?php /**PATH D:\xampp\htdocs\laravelrole\resources\views\backend\layouts\partials\header.blade.php ENDPATH**/ ?>