<?php $__env->startSection('title'); ?>
Receive - Admin Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Receive Item Create</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li>All Receive</a></li>
                    <li><span>Create Receive Item</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            <?php echo $__env->make('backend.layouts.partials.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Create New Receive Item</h4>
                    <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <form action="<?php echo e(route('receives.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="eid">Employee ID</label>
                                <select name="eid" id="eid" class="form-control">
                                    <option value="0" disabled="true" selected="true">-Select-</option>
                                    <?php $__currentLoopData = $assigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($assign->eid); ?>"><?php echo e($assign->eid); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="itemcode">Item code</label>
                                    <select name="itemcode" id="itemcode" class="form-control">
                                        <option selected>Choose...</option>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->itemcode); ?>"><?php echo e($item->itemcode); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="itemdes">Item Description</label>
                                    <input type="text" class="form-control" id="itemdes" name="itemdes" placeholder="Enter Item Description">
                                </div>
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="rdate">Receive Date</label>
                                <input class="form-control" type="date" id="rdate" name="rdate">
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="ri">Receive/Issue</label>
                                    <select name="ri" id="ri" style="width: 560px; height: 45px;">
                                        <option value="0" disabled="true" selected="true">-Select-</option>
                                        <option value="receive">Receive</option>
                                        <option value="issue">Issue</option>
                                    </select>
                            </div>

                        </div>

                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save Receive Item</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>

<script>
    /*================================
   datatable active
   ==================================*/
   if ($('#dataTable').length) {
       $('#dataTable').DataTable({
           responsive: true
       });
   }
   $('#eid').on('input', function(e){
       var eid_ = $('#eid option:selected').val();
       $.ajax({
           type:"GET",
           url:"<?php echo e(url('receives/getitemcode')); ?>",
           data:{
            eid: eid_
           },
           success: function(data){
               if(data){
                   $('#itemcode').val(data);
               }else{
                   $('#itemcode').val('');
               }
           }
       });

   });

   $('#itemcode').on('input', function(e){
      var itemcode_ = $('#itemcode option:selected').val();
      $.ajax({
          type:"GET",
          url:"<?php echo e(url('receives/getitem')); ?>",
          data:{
           itemcode: itemcode_
          },
          success: function(data){
              if(data){
                  $('#itemdes').val(data);
              }else{
                  $('#itemdes').val('');
              }
          }
      });

  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelrole\resources\views\backend\pages\receives\create.blade.php ENDPATH**/ ?>