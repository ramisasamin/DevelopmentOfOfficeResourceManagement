<?php $__env->startSection('title'); ?>
Miscellany - Admin Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Miscellaneous Create</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('transactions.index')); ?>">All Miscellany</a></li>
                    <li><span>Create Miscellaneous</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            <?php echo $__env->make('backend.layouts.partials.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Create New Miscellaneous</h4>
                    <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <form action="<?php echo e(route('transactions.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="transdate">Miscellaneous Date</label>
                                <input class="form-control" type="date" id="transdate" name="transdate">
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="transtype">Miscellaneous Type</label>
                                    <select name="transtype" id="transtype" style="width: 560px; height: 45px;">
                                        <option value="miscellaneousissue">Miscellaneous Issue</option>
                                        <option value="miscellaneousreceipt">Miscellaneous Receipt</option>
                                    </select>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="itemcode">Item code</label>
                                    <select name="itemcode" id="itemcode" class="form-control">
                                        <option selected>Choose...</option>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->itemcode); ?>"><?php echo e($item->itemcode); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="itemdes">Item Description</label>
                                    <input type="text" class="form-control" id="itemdes" name="itemdes" placeholder="Enter Item Description">
                                </div>
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="quantity">Quantity</label>
                                <input type="text" class="form-control" id="quantity" name="quantity" placeholder="Enter Quantity">
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="invcode">Inventory Code</label>
                                    <select name="invcode" id="invcode" class="form-control">
                                        <option selected>Choose...</option>
                                        <?php $__currentLoopData = $inventoryorgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventoryorg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($inventoryorg->invcode); ?>"><?php echo e($inventoryorg->invcode); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-6 col-sm-12">
                                    <label for="invname">Inventory Name</label>
                                    <input type="text" class="form-control" id="invname" name="invname"  placeholder="Enter Inventory Name">
                                </div>
                            </div>

                        </div>

                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save Miscellaneous</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
<script>
    /*================================
   datatable active
   ==================================*/
   if ($('#dataTable').length) {
       $('#dataTable').DataTable({
           responsive: true
       });
   }
   $('#invcode').on('input', function(e){
       var invcode_ = $('#invcode option:selected').val();
       $.ajax({
           type:"GET",
           url:"<?php echo e(url('transactions/getinv')); ?>",
           data:{
               invcode: invcode_
           },
           success: function(data){
               if(data){
                   $('#invname').val(data);
               }else{
                   $('#invname').val('');
               }
           }
       });

   });
   $('#itemcode').on('input', function(e){
      var itemcode_ = $('#itemcode option:selected').val();
      $.ajax({
          type:"GET",
          url:"<?php echo e(url('transactions/getitem')); ?>",
          data:{
           itemcode: itemcode_
          },
          success: function(data){
              if(data){
                  $('#itemdes').val(data);
              }else{
                  $('#itemdes').val('');
              }
          }
      });

  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelrole\resources\views/backend/pages/transactions/create.blade.php ENDPATH**/ ?>