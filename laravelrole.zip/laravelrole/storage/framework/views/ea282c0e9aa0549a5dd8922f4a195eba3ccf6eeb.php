<!doctype html>
<html class="no-js') }}" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Employee Profile - Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->make('backend.layouts.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>

</head>

<body>

    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->


        <!-- main content area start -->
        <div class="main-content">

            <div class="main-content-inner">
                <div class="row">
                    <!-- data table start -->
                    <div class="col-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Profile Employee - <?php echo e($user->name); ?></h4>
                                <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
                                    
                                    <div class="form-row">
                                        <div class="form-group col-md-2 col-sm-12">
                                            <label for="titlename">Title</label>
                                            <select name="titlename" id="titlename" class="form-control">
                                                
                                                <?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($title->titlename); ?>" <?php echo e($title->titlename == $user->titlename ? 'selected': ''); ?>><?php echo e($title->titlename); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-5 col-sm-12">
                                            <label for="name">First Name</label>
                                            <input type="text" class="form-control" id="name" name="name" placeholder="Enter First Name" value="<?php echo e($user->name); ?>">
                                        </div>
                                        <div class="form-group col-md-5 col-sm-12">
                                            <label for="namel">Last name</label>
                                            <input type="text" class="form-control" id="namel" name="namel" placeholder="Enter Last Email" value="<?php echo e($user->namel); ?>">
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="fname">Father's Name</label>
                                            <input type="text" class="form-control" id="fname" name="fname" placeholder="Enter Father's Name" value="<?php echo e($user->fname); ?>">
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="fno">Father's Phone Number</label>
                                            <input type="text" class="form-control" id="fno" name="fno" placeholder="Enter Father's Number" value="<?php echo e($user->fno); ?>">
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="mname">Mother's Name</label>
                                            <input type="text" class="form-control" id="mname" name="mname" placeholder="Enter Mother's Name" value="<?php echo e($user->mname); ?>">
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="mno">Mother's Phone Number</label>
                                            <input type="text" class="form-control" id="mno" name="mno" placeholder="Enter Mother's Number" value="<?php echo e($user->mno); ?>">
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="gendername">Gender</label>
                                            <select name="gendername" id="gendername" class="form-control"  value="<?php echo e($user->mno); ?>" >
                                                <!-- <option selected>Choose...</option> -->
                                                <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($gender->gendername); ?>" <?php echo e($gender->gendername == $user->gendername ? 'selected': ''); ?>><?php echo e($gender->gendername); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="systemtype">Emploment Type</label>
                                            <select name="systemtype" id="systemtype" class="form-control" value="<?php echo e($user->systemtype); ?>" >
                                                <!-- <option selected>Choose...</option> -->
                                                <?php $__currentLoopData = $persontypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ptype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($ptype->systemtype); ?>" <?php echo e($ptype->systemtype == $user->systemtype ? 'selected': ''); ?>><?php echo e($ptype->systemtype); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="eid">Office ID</label>
                                            <input type="text" class="form-control" id="eid" name="eid" placeholder="Enter ID" value="<?php echo e($user->eid); ?>">
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="nid">NID</label>
                                            <input type="text" class="form-control" id="nid" name="nid" placeholder="Enter NID" value="<?php echo e($user->nid); ?>">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-2 col-sm-12">
                                            <br><label>Effective Dates: </label>
                                        </div>
                                        <div class="form-group col-md-5 col-sm-12">
                                            <label for="start">From</label>
                                            <input class="form-control" type="date" id="start" name="start" value="<?php echo e($user->start); ?>">
                                        </div>
                                        <div class="form-group col-md-5 col-sm-12">
                                            <label for="end">To</label>
                                            <input class="form-control" type="date" id="end" name="end" value="<?php echo e($user->end); ?>">
                                        </div>
                                    </div>

                                    <hr>

                                    <div class="form-row">
                                        <div class="form-group col-md-6 col-sm-12">
                                            <h5 style="color: black">Personal Information</h5>
                                            <br>
                                            <div class="form-group col-md-12">
                                                <label for="bd">Date of Birth</label>
                                                <input class="form-control" type="date" id="bd" name="bd" placeholder="Enter Date of Birth" value="<?php echo e($user->bd); ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="place">Place of Birth</label>
                                                <input class="form-control" type="date" id="place" name="place" placeholder="Enter Place of Birth" value="<?php echo e($user->place); ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="maritalstatus">Marital Status</label>
                                                <select name="" id="maritalstatus" class="form-control" value="<?php echo e($user->maritalstatus); ?>">
                                                    <!-- <option selected>Choose...</option> -->
                                                    <?php $__currentLoopData = $maritals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($marital->maritalstatus); ?>" <?php echo e($marital->maritalstatus == $user->maritalstatus ? 'selected': ''); ?>><?php echo e($marital->maritalstatus); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="nationalityname">Nationality</label>
                                                <select name="" id="nationalityname" class="form-control" value="<?php echo e($user->nationalityname); ?>">
                                                    <!-- <option selected>Choose...</option> -->
                                                    <?php $__currentLoopData = $nationalities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($nationality->nationalityname); ?>" <?php echo e($nationality->nationalityname == $user->nationalityname ? 'selected': ''); ?>><?php echo e($nationality->nationalityname); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label>Upload Picture</label>
                                                <div class="form-group col-md-12">
                                                <input type="file" class="custom-file-input" id="image" name="image" value="<?php echo e($user->image); ?>" >
                                                <label class="custom-file-label" for="image">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <h5 style="color: black">Office Details</h5>
                                            <br>
                                            <div class="form-group col-md-12">
                                                <label for="office">Office</label>
                                                <input type="text" class="form-control" id="office" name="office" placeholder="Enter Office" value="<?php echo e($user->office); ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="address">Address</label>
                                                <input type="text" class="form-control" id="address" name="address" placeholder="Enter Address" value="<?php echo e($user->address); ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="mail">Email</label>
                                                <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" value="<?php echo e($user->email); ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="ono">Office Mobile Number</label>
                                                <input type="text" class="form-control" id="ono" name="ono" placeholder="Enter Phone Number" value="<?php echo e($user->ono); ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="pno">Personal Mobile Number</label>
                                                <input type="text" class="form-control" id="pno" name="pno" placeholder="Enter Phone Number" value="<?php echo e($user->pno); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <hr>
                                    <h5 style="color: black">Assignment</h5>
                                    <br>

                                    <div class="form-row">
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="shortname">Organization</label>
                                            <select name="" id="shortname" class="form-control"  value="<?php echo e($user->shortname); ?>">
                                                <!-- <option selected>Choose...</option> -->
                                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($unit->shortname); ?>" <?php echo e($unit->shortname == $user->shortname ? 'selected': ''); ?>><?php echo e($unit->shortname); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="statusassign">Status</label>
                                            <select name="" id="statusassign" class="form-control" value="<?php echo e($user->statusassign); ?>">
                                                <!-- <option selected>Choose...</option> -->
                                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($status->statusassign); ?>" <?php echo e($status->statusassign == $user->statusassign ? 'selected': ''); ?>><?php echo e($status->statusassign); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="jobname">Job Position</label>
                                            <select name="" id="jobname" class="form-control"  value="<?php echo e($user->jobname); ?>">
                                                <!-- <option selected>Choose...</option> -->
                                                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($job->jobname); ?>" <?php echo e($job->jobname == $user->jobname ? 'selected': ''); ?>><?php echo e($job->jobname); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="sscale">Salary Scale</label>
                                            <input type="text" class="form-control" id="sscale" name="sscale" placeholder="Enter Salary Scale" value="<?php echo e($user->sscale); ?>">
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="gradecode">Grade</label>
                                            <select name="" id="gradecode" class="form-control" value="<?php echo e($user->gradecode); ?>">
                                                <!-- <option selected>Choose...</option> -->
                                                <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($grade->gradecode); ?>" <?php echo e($grade->gradecode == $user->gradecode ? 'selected': ''); ?>><?php echo e($grade->gradecode); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="supname">Supervisor's Name</label>
                                            <input type="text" class="form-control" id="supname" name="supname" placeholder="Enter Supervisor's Name" value="<?php echo e($user->supname); ?>">
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="locationcode">Location</label>
                                            <select name="" id="locationcode" class="form-control"  value="<?php echo e($user->locationcode); ?>">
                                                <!-- <option selected>Choose...</option> -->
                                                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($location->locationcode); ?>" <?php echo e($location->locationcode == $user->locationcode ? 'selected': ''); ?>><?php echo e($location->locationcode); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="supno">Supervisor's Number</label>
                                            <input type="text" class="form-control" id="supno" name="supno" placeholder="Enter Supervisor's Number" value="<?php echo e($user->supno); ?>">
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="assignno">Assignment Number</label>
                                            <input type="text" class="form-control" id="assignno" name="assignno" placeholder="Enter Assignment Number" value="<?php echo e($user->assignno); ?>">
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="period">Probation Period Length</label>
                                            <input type="text" class="form-control" id="period" name="period" placeholder="Enter Period Length" value="<?php echo e($user->period); ?>">
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="categoryname">Assignment Category</label>
                                            <select name="" id="categoryname" class="form-control" value="<?php echo e($user->categoryname); ?>">
                                                <!-- <option selected>Choose...</option> -->
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->categoryname); ?>" <?php echo e($category->categoryname == $user->categoryname ? 'selected': ''); ?>><?php echo e($category->categoryname); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="periodend">Probation Period End</label>
                                            <input type="text" class="form-control" id="periodend" name="periodend" placeholder="Enter Period End" value="<?php echo e($user->periodend); ?>">
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="grp">Group</label>
                                            <select class="form-control" id="grp" name="grp" value="<?php echo e($user->grp); ?>">
                                                <!-- <option selected>Choose...</option> -->
                                                <option value="1">PSG</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="notice">Notice Period Length</label>
                                            <input type="text" class="form-control" id="notice" name="notice" placeholder="Enter Period Length" value="<?php echo e($user->notice); ?>">
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="positionname">Position</label>
                                            <select name="" id="positionname" class="form-control"  value="<?php echo e($user->positionname); ?>">
                                                <!-- <option selected>Choose...</option> -->
                                                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($position->positionname); ?>" <?php echo e($position->positionname == $user->positionname ? 'selected': ''); ?>><?php echo e($position->positionname); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="whour">Working Hours</label>
                                            <input type="text" class="form-control" id="whour" name="whour" placeholder="Enter Working Hours" value="<?php echo e($user->whour); ?>">
                                        </div>
                                    </div>

                                    <hr>
                                    <h5 style="color: black">Salary Determination</h5>
                                    <br>

                                    <div>
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="shr">Salary/Hour</label>
                                            <input type="text" class="form-control" id="shr" name="shr" placeholder="Enter Amount" value="<?php echo e($user->shr); ?>">
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-2 col-sm-12">
                                                <br><label>Working Hours</label>
                                            </div>
                                            <div class="form-group col-md-5 col-sm-12">
                                                <input class="form-control" type="time" id="stime" name="stime">
                                            </div>
                                            <div class="form-group col-md-5 col-sm-12">
                                                <input class="form-control" type="time" id="etime" name="etime">
                                            </div>
                                        </div>
                                        <br>
                                        <div class="form-check">
                                            <label class="form-check-label">
                                              <input type="checkbox" class="form-check-input" value="checkbox" <?php echo e($user->checkbox == 'checkbox' ? 'checked' : ''); ?>>Work from Home
                                            </label>
                                        </div>
                                        <br>
                                        <div class="form-row">
                                            <div class="form-group col-md-2 col-sm-12">
                                                <br><label>Effective Dates</label>
                                            </div>
                                            <div class="form-group col-md-5 col-sm-12">
                                                <input class="form-control" type="date" id="datestart" name="datestart" value="<?php echo e($user->datestart); ?>">
                                            </div>
                                            <div class="form-group col-md-5 col-sm-12">
                                                <input class="form-control" type="date" id="dateend" name="dateend" value="<?php echo e($user->dateend); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="hidden-print">
                                        <div class="pull-right">
                                            <a href="#" onclick="window.print()" class="btn btn-primary mt-4 pr-4 pl-4"><i class="fa fa-print">Print</i></a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- data table end -->

                </div>
            </div>


        </div>


        <!-- main content area end -->

        <?php echo $__env->make('backend.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;



    <!-- page container area end -->

    <?php echo $__env->make('backend.layouts.partials.offsets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <?php echo $__env->make('backend.layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.select2').select2();
        })
    </script>

</body>

</html>
<?php /**PATH D:\xampp\htdocs\laravelrole\resources\views/backend/pages/users/show.blade.php ENDPATH**/ ?>