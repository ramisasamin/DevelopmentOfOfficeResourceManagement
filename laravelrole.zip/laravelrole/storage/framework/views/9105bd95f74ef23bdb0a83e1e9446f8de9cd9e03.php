<?php $__env->startSection('title'); ?>
Inventory Location Create - Admin Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Inventory Location Creation Form</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('inventoryorgs.index')); ?>">All Inventory Locations</a></li>
                    <li><span>Create Inventory Location</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            <?php echo $__env->make('backend.layouts.partials.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Create New Inventory</h4>
                    <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <form action="<?php echo e(route('inventoryorgs.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-row">
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="istart">Date From</label>
                                <input class="form-control" type="date" id="istart" name="istart">
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="iend">Date To</label>
                                <input class="form-control" type="date" id="iend" name="iend">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="lname">Location</label>
                                <select name="lname" id="lname" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $ilocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ilocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ilocation->lname); ?>"><?php echo e($ilocation->lname); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="ladd">Location Address</label>
                                <select name="ladd" id="ladd" class="form-control">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $ilocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ilocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ilocation->ladd); ?>"><?php echo e($ilocation->ladd); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="invcode">Inventory Code</label>
                                <input type="text" class="form-control" id="invcode" name="invcode" placeholder="Enter Inventory Code">
                            </div>
                            <div class="form-group col-md-5 col-sm-12">
                                <label for="invname">Inventory name</label>
                                <input type="text" class="form-control" id="invname" name="invname" placeholder="Enter Inventory name">
                            </div>
                        </div>

                        <div class="form-group col-md-6 col-sm-12">
                            <label for="ledgername">Primary Ledger</label>
                            <select name="ledgername" id="ledgername" class="form-control">
                                <option selected>Choose...</option>
                                <?php $__currentLoopData = $ledgers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ledger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ledger->ledgername); ?>"><?php echo e($ledger->ledgername); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6 col-sm-12">
                            <label for="legalname">Legal Entity</label>
                            <select name="legalname" id="legalname" class="form-control">
                                <option selected>Choose...</option>
                                <?php $__currentLoopData = $legals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $legal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($legal->legalname); ?>"><?php echo e($legal->legalname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6 col-sm-12">
                            <label for="shortname">Organization</label>
                            <select name="shortname" id="shortname" class="form-control">
                                <option selected>Choose...</option>
                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->shortname); ?>"><?php echo e($unit->shortname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>


                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save Inventory Location</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelrole\resources\views/backend/pages/inventoryorgs/create.blade.php ENDPATH**/ ?>