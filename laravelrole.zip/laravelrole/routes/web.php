<?php

use Illuminate\Support\Facades\Route;


// Route::get('/', function () {
//     return view('welcome');
// });

//Auth::routes();

Route::get('/', [App\Http\Controllers\HomeController::class, 'redirectAdmin'])->name('index');
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// Route::group(['prefix' => 'admin'],function(){
//     Route::get('/', [App\Http\Controllers\Backend\DashBoardContoller::class, 'index']) -> name ('admin.dashboard');
//     Route::resource('/roles', [App\Http\Controllers\Backend\RolesController::class], ['name' => 'roles.store']);
// });
Route::get('/admin', [App\Http\Controllers\Backend\DashboardController::class, 'index'])-> name ('admin.dashboard');

// Route::get('/dashboard', function () {
//     return 'ok';
// });

Route::get('/roles',[App\Http\Controllers\Backend\RolesController::class, 'index'])->name('roles.index');
Route::get('/roles/create',[App\Http\Controllers\Backend\RolesController::class, 'create'])->name('roles.create');
Route::post('/roles',[App\Http\Controllers\Backend\RolesController::class, 'store'])->name('roles.store');
Route::get('/roles/edit/{id}',[App\Http\Controllers\Backend\RolesController::class, 'edit'])->name('roles.edit');
Route::post('/roles/update/{id}',[App\Http\Controllers\Backend\RolesController::class, 'update'])->name('roles.update');
Route::get('/roles/delete/{id}',[App\Http\Controllers\Backend\RolesController::class, 'delete'])->name('roles.delete');

Route::get('/users', [App\Http\Controllers\Backend\UsersController::class, 'index'])->name('users.index');
Route::get('/users/create',[App\Http\Controllers\Backend\UsersController::class, 'create'])->name('users.create');
Route::post('/users',[App\Http\Controllers\Backend\UsersController::class, 'store'])->name('users.store');
Route::get('/users/show/{id}',[App\Http\Controllers\Backend\UsersController::class, 'show'])->name('users.show');
Route::get('/users/edit/{id}',[App\Http\Controllers\Backend\UsersController::class, 'edit'])->name('users.edit');
Route::post('/users/update/{id}',[App\Http\Controllers\Backend\UsersController::class, 'update'])->name('users.update');
Route::get('/users/delete/{id}',[App\Http\Controllers\Backend\UsersController::class, 'delete'])->name('users.delete');

Route::get('/admins', [App\Http\Controllers\Backend\AdminsController::class, 'index'])->name('admins.index');
Route::get('/admins/create',[App\Http\Controllers\Backend\AdminsController::class, 'create'])->name('admins.create');
Route::post('/admins',[App\Http\Controllers\Backend\AdminsController::class, 'store'])->name('admins.store');
Route::get('/admins/edit/{id}',[App\Http\Controllers\Backend\AdminsController::class, 'edit'])->name('admins.edit');
Route::post('/admins/update/{id}',[App\Http\Controllers\Backend\AdminsController::class, 'update'])->name('admins.update');
Route::get('/admins/delete/{id}',[App\Http\Controllers\Backend\AdminsController::class, 'delete'])->name('admins.delete');

// Login Routes
Route::get('/login', [App\Http\Controllers\Backend\Auth\LoginController::class, 'showLoginForm'])->name('admin.login');
Route::post('/login/submit', [App\Http\Controllers\Backend\Auth\LoginController::class, 'login'])->name('admin.login.submit');

// Logout Routes
Route::post('/logout/submit', [App\Http\Controllers\Backend\Auth\LoginController::class, 'logout'])->name('admin.logout.submit');

// Forget Password Routes
//Route::get('/password/reset', [App\Http\Controllers\Backend\Auth\ForgetPasswordController::class, 'showLinkRequestForm'])->name('admin.password.request');
//Route::post('/password/reset/submit', [App\Http\Controllers\Backend\Auth\ForgetPasswordController::class, 'reset'])->name('admin.password.update');

Route::get('/units', [App\Http\Controllers\Backend\UnitsController::class, 'index'])->name('units.index');
Route::get('/units/create',[App\Http\Controllers\Backend\UnitsController::class, 'create'])->name('units.create');
Route::post('/units',[App\Http\Controllers\Backend\UnitsController::class, 'store'])->name('units.store');
Route::get('/units/edit/{id}',[App\Http\Controllers\Backend\UnitsController::class, 'edit'])->name('units.edit');
Route::post('/units/update/{id}',[App\Http\Controllers\Backend\UnitsController::class, 'update'])->name('units.update');
Route::get('/units/delete/{id}',[App\Http\Controllers\Backend\UnitsController::class, 'delete'])->name('units.delete');

Route::get('/jobs', [App\Http\Controllers\Backend\JobsController::class, 'index'])->name('jobs.index');
Route::get('/jobs/create',[App\Http\Controllers\Backend\JobsController::class, 'create'])->name('jobs.create');
Route::post('/jobs',[App\Http\Controllers\Backend\JobsController::class, 'store'])->name('jobs.store');
Route::get('/jobs/edit/{id}',[App\Http\Controllers\Backend\JobsController::class, 'edit'])->name('jobs.edit');
Route::post('/jobs/update/{id}',[App\Http\Controllers\Backend\JobsController::class, 'update'])->name('jobs.update');
Route::get('/jobs/delete/{id}',[App\Http\Controllers\Backend\JobsController::class, 'delete'])->name('jobs.delete');

Route::get('/positions', [App\Http\Controllers\Backend\PositionsController::class, 'index'])->name('positions.index');
Route::get('/positions/create',[App\Http\Controllers\Backend\PositionsController::class, 'create'])->name('positions.create');
Route::post('/positions',[App\Http\Controllers\Backend\PositionsController::class, 'store'])->name('positions.store');
Route::get('/positions/edit/{id}',[App\Http\Controllers\Backend\PositionsController::class, 'edit'])->name('positions.edit');
Route::post('/positions/update/{id}',[App\Http\Controllers\Backend\PositionsController::class, 'update'])->name('positions.update');
Route::get('/positions/delete/{id}',[App\Http\Controllers\Backend\PositionsController::class, 'delete'])->name('positions.delete');

Route::get('/grades', [App\Http\Controllers\Backend\GradesController::class, 'index'])->name('grades.index');
Route::get('/grades/create',[App\Http\Controllers\Backend\GradesController::class, 'create'])->name('grades.create');
Route::post('/grades',[App\Http\Controllers\Backend\GradesController::class, 'store'])->name('grades.store');
Route::get('/grades/edit/{id}',[App\Http\Controllers\Backend\GradesController::class, 'edit'])->name('grades.edit');
Route::post('/grades/update/{id}',[App\Http\Controllers\Backend\GradesController::class, 'update'])->name('grades.update');
Route::get('/grades/delete/{id}',[App\Http\Controllers\Backend\GradesController::class, 'delete'])->name('grades.delete');

Route::get('/categories', [App\Http\Controllers\Backend\CategoriesController::class, 'index'])->name('categories.index');
Route::get('/categories/create',[App\Http\Controllers\Backend\CategoriesController::class, 'create'])->name('categories.create');
Route::post('/categories',[App\Http\Controllers\Backend\CategoriesController::class, 'store'])->name('categories.store');
Route::get('/categories/edit/{id}',[App\Http\Controllers\Backend\CategoriesController::class, 'edit'])->name('categories.edit');
Route::post('/categories/update/{id}',[App\Http\Controllers\Backend\CategoriesController::class, 'update'])->name('categories.update');
Route::get('/categories/delete/{id}',[App\Http\Controllers\Backend\CategoriesController::class, 'delete'])->name('categories.delete');

Route::get('/locations', [App\Http\Controllers\Backend\LocationsController::class, 'index'])->name('locations.index');
Route::get('/locations/create',[App\Http\Controllers\Backend\LocationsController::class, 'create'])->name('locations.create');
Route::post('/locations',[App\Http\Controllers\Backend\LocationsController::class, 'store'])->name('locations.store');
Route::get('/locations/edit/{id}',[App\Http\Controllers\Backend\LocationsController::class, 'edit'])->name('locations.edit');
Route::post('/locations/update/{id}',[App\Http\Controllers\Backend\LocationsController::class, 'update'])->name('locations.update');
Route::get('/locations/delete/{id}',[App\Http\Controllers\Backend\LocationsController::class, 'delete'])->name('locations.delete');

Route::get('/nationalities', [App\Http\Controllers\Backend\NationalsController::class, 'index'])->name('nationalities.index');
Route::get('/nationalities/create',[App\Http\Controllers\Backend\NationalsController::class, 'create'])->name('nationalities.create');
Route::post('/nationalities',[App\Http\Controllers\Backend\NationalsController::class, 'store'])->name('nationalities.store');
Route::get('/nationalities/edit/{id}',[App\Http\Controllers\Backend\NationalsController::class, 'edit'])->name('nationalities.edit');
Route::post('/nationalities/update/{id}',[App\Http\Controllers\Backend\NationalsController::class, 'update'])->name('nationalities.update');
Route::get('/nationalities/delete/{id}',[App\Http\Controllers\Backend\NationalsController::class, 'delete'])->name('nationalities.delete');

Route::get('/ilocations', [App\Http\Controllers\Backend\IlocationsController::class, 'index'])->name('ilocations.index');
Route::get('/ilocations/create',[App\Http\Controllers\Backend\IlocationsController::class, 'create'])->name('ilocations.create');
Route::post('/ilocations',[App\Http\Controllers\Backend\IlocationsController::class, 'store'])->name('ilocations.store');
Route::get('/ilocations/edit/{id}',[App\Http\Controllers\Backend\IlocationsController::class, 'edit'])->name('ilocations.edit');
Route::post('/ilocations/update/{id}',[App\Http\Controllers\Backend\IlocationsController::class, 'update'])->name('ilocations.update');
Route::get('/ilocations/delete/{id}',[App\Http\Controllers\Backend\IlocationsController::class, 'delete'])->name('ilocations.delete');

Route::get('/legals', [App\Http\Controllers\Backend\LegalsController::class, 'index'])->name('legals.index');
Route::get('/legals/create',[App\Http\Controllers\Backend\LegalsController::class, 'create'])->name('legals.create');
Route::post('/legals',[App\Http\Controllers\Backend\LegalsController::class, 'store'])->name('legals.store');
Route::get('/legals/edit/{id}',[App\Http\Controllers\Backend\LegalsController::class, 'edit'])->name('legals.edit');
Route::post('/legals/update/{id}',[App\Http\Controllers\Backend\LegalsController::class, 'update'])->name('legals.update');
Route::get('/legals/delete/{id}',[App\Http\Controllers\Backend\LegalsController::class, 'delete'])->name('legals.delete');

Route::get('/ledgers', [App\Http\Controllers\Backend\LedgersController::class, 'index'])->name('ledgers.index');
Route::get('/ledgers/create',[App\Http\Controllers\Backend\LedgersController::class, 'create'])->name('ledgers.create');
Route::post('/ledgers',[App\Http\Controllers\Backend\LedgersController::class, 'store'])->name('ledgers.store');
Route::get('/ledgers/edit/{id}',[App\Http\Controllers\Backend\LedgersController::class, 'edit'])->name('ledgers.edit');
Route::post('/ledgers/update/{id}',[App\Http\Controllers\Backend\LedgersController::class, 'update'])->name('ledgers.update');
Route::get('/ledgers/delete/{id}',[App\Http\Controllers\Backend\LedgersController::class, 'delete'])->name('ledgers.delete');

Route::get('/inventoryorgs', [App\Http\Controllers\Backend\InventoryorgsController::class, 'index'])->name('inventoryorgs.index');
Route::get('/inventoryorgs/create',[App\Http\Controllers\Backend\InventoryorgsController::class, 'create'])->name('inventoryorgs.create');
Route::post('/inventoryorgs',[App\Http\Controllers\Backend\InventoryorgsController::class, 'store'])->name('inventoryorgs.store');
Route::get('/inventoryorgs/edit/{id}',[App\Http\Controllers\Backend\InventoryorgsController::class, 'edit'])->name('inventoryorgs.edit');
Route::post('/inventoryorgs/update/{id}',[App\Http\Controllers\Backend\InventoryorgsController::class, 'update'])->name('inventoryorgs.update');
Route::get('/inventoryorgs/delete/{id}',[App\Http\Controllers\Backend\InventoryorgsController::class, 'delete'])->name('inventoryorgs.delete');

Route::get('/transactions', [App\Http\Controllers\Backend\TransactionsController::class, 'index'])->name('transactions.index');
Route::get('/transactions/create',[App\Http\Controllers\Backend\TransactionsController::class, 'create'])->name('transactions.create');
Route::post('/transactions',[App\Http\Controllers\Backend\TransactionsController::class, 'store'])->name('transactions.store');
Route::get('/transactions/edit/{id}',[App\Http\Controllers\Backend\TransactionsController::class, 'edit'])->name('transactions.edit');
Route::post('/transactions/update/{id}',[App\Http\Controllers\Backend\TransactionsController::class, 'update'])->name('transactions.update');
Route::get('/transactions/delete/{id}',[App\Http\Controllers\Backend\TransactionsController::class, 'delete'])->name('transactions.delete');
Route::get('/transactions/getinv','App\Http\Controllers\Backend\TransactionsController@getInv');
Route::get('/transactions/getitem','App\Http\Controllers\Backend\TransactionsController@getItem');

Route::get('/items', [App\Http\Controllers\Backend\ItemsController::class, 'index'])->name('items.index');
Route::get('/items/create',[App\Http\Controllers\Backend\ItemsController::class, 'create'])->name('items.create');
Route::post('/items',[App\Http\Controllers\Backend\ItemsController::class, 'store'])->name('items.store');
Route::get('/items/show/{id}',[App\Http\Controllers\Backend\ItemsController::class, 'show'])->name('items.show');
Route::get('/items/edit/{id}',[App\Http\Controllers\Backend\ItemsController::class, 'edit'])->name('items.edit');
Route::post('/items/update/{id}',[App\Http\Controllers\Backend\ItemsController::class, 'update'])->name('items.update');
Route::get('/items/delete/{id}',[App\Http\Controllers\Backend\ItemsController::class, 'delete'])->name('items.delete');
Route::get('/items/getinv', 'App\Http\Controllers\Backend\ItemsController@getInv');

Route::get('/onhands', [App\Http\Controllers\Backend\OnhandsController::class, 'index'])->name('onhands.index');
Route::post('/find', [App\Http\Controllers\Backend\OnhandsController::class, 'find'])->name('onhands.find');
Route::get('/onhands/getinv','App\Http\Controllers\Backend\OnhandsController@getInv');
Route::get('/onhands/getitem','App\Http\Controllers\Backend\OnhandsController@getItem');

Route::get('/assigns', [App\Http\Controllers\Backend\AssignsController::class, 'index'])->name('assigns.index');
Route::get('/assigns/create',[App\Http\Controllers\Backend\AssignsController::class, 'create'])->name('assigns.create');
Route::post('/assigns',[App\Http\Controllers\Backend\AssignsController::class, 'store'])->name('assigns.store');
Route::get('/assigns/edit/{id}',[App\Http\Controllers\Backend\AssignsController::class, 'edit'])->name('assigns.edit');
Route::post('/assigns/update/{id}',[App\Http\Controllers\Backend\AssignsController::class, 'update'])->name('assigns.update');
Route::get('/assigns/delete/{id}',[App\Http\Controllers\Backend\AssignsController::class, 'delete'])->name('assigns.delete');
Route::get('/assigns/getemp', 'App\Http\Controllers\Backend\AssignsController@getEmp');
Route::get('/assigns/getinv','App\Http\Controllers\Backend\AssignsController@getInv');
Route::get('/assigns/getitem','App\Http\Controllers\Backend\AssignsController@getItem');

Route::get('/receives/create',[App\Http\Controllers\Backend\ReceivesController::class, 'create'])->name('receives.create');
Route::post('/receives',[App\Http\Controllers\Backend\ReceivesController::class, 'store'])->name('receives.store');
Route::get('/receives/edit/{id}',[App\Http\Controllers\Backend\ReceivesController::class, 'edit'])->name('receives.edit');
Route::post('/receives/update/{id}',[App\Http\Controllers\Backend\ReceivesController::class, 'update'])->name('receives.update');
Route::get('/receives/delete/{id}',[App\Http\Controllers\Backend\ReceivesController::class, 'delete'])->name('receives.delete');
Route::get('/receives/getitemcode', 'App\Http\Controllers\Backend\ReceivesController@getItemcode');
Route::get('/receives/getitem','App\Http\Controllers\Backend\ReceivesController@getItem');

