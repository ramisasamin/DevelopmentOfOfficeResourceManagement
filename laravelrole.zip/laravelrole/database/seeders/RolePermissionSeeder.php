<?php

namespace Database\Seeders;
use App\Models\User;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;


class RolePermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //create roles
        $roleSuperAdmin = Role::create(['name' => 'superadmin']);
        //$roleAdmin = Role::create(['name' => 'admin']);
        //$roleEditor = Role::create(['name' => 'editor']);
        //$roleUser = Role::create(['name' => 'user']);

        //permission list
        $permissions = [
            [
                'group_name' => 'dashboard',
                'permissions' => [
                    'dashboard.view',
                    'dashboard.edit',
                ]
            ],
            [
                'group_name' => 'employee',
                'permissions' => [
                    // Blog Permissions
                    'employee.create',
                    'employee.view',
                    'employee.edit',
                    'employee.delete',
                    'employee.approve',
                ]
            ],
            [
                'group_name' => 'admin',
                'permissions' => [
                    // admin Permissions
                    'admin.create',
                    'admin.view',
                    'admin.edit',
                    'admin.delete',
                    'admin.approve',
                ]
            ],
            [
                'group_name' => 'role',
                'permissions' => [
                    // role Permissions
                    'role.create',
                    'role.view',
                    'role.edit',
                    'role.delete',
                    'role.approve',
                ]
            ],
           
            
            [
                'group_name' => 'manage',
                'permissions' => [
                    // Blog Permissions
                    'manage.create',
                    'manage.view',
                    'manage.edit',
                    'manage.delete',
                    'manage.approve',
                ]
            ],

            [
                'group_name' => 'invorganization',
                'permissions' => [
                    // Blog Permissions
                    'invorganization.create',
                    'invorganization.view',
                    'invorganization.edit',
                    'invorganization.delete',
                    'invorganization.approve',
                ]
            ],

            [
                'group_name' => 'invlocation',
                'permissions' => [
                    // Blog Permissions
                    'invlocation.create',
                    'invlocation.view',
                    'invlocation.edit',
                    'invlocation.delete',
                    'invlocation.approve',
                ]
            ],

            [
                'group_name' => 'invtransaction',
                'permissions' => [
                    // Blog Permissions
                    'invtransaction.create',
                    'invtransaction.view',
                    'invtransaction.edit',
                    'invtransaction.delete',
                    'invtransaction.approve',
                ]
            ],

            [
                'group_name' => 'invonhand',
                'permissions' => [
                    // Blog Permissions
                    'invonhand.create',
                    'invonhand.view',
                    'invonhand.edit',
                    'invonhand.delete',
                    'invonhand.approve',
                ]
            ],

            [
                'group_name' => 'item',
                'permissions' => [
                    // Blog Permissions
                    'item.create',
                    'item.view',
                    'item.edit',
                    'item.delete',
                    'item.approve',
                ]
            ],

            [
                'group_name' => 'assignitem',
                'permissions' => [
                    // Blog Permissions
                    'assignitem.create',
                    'assignitem.view',
                    'assignitem.edit',
                    'assignitem.delete',
                    'assignitem.approve',
                ]
            ],

            [
                'group_name' => 'receiveitem',
                'permissions' => [
                    // Blog Permissions
                    'receiveitem.create',
                    'receiveitem.view',
                    'receiveitem.edit',
                    'receiveitem.delete',
                    'receiveitem.approve',
                ]
            ],



            


        ];

        for ($i = 0; $i < count($permissions); $i++) {
            $permissionGroup = $permissions[$i]['group_name'];
            for ($j = 0; $j < count($permissions[$i]['permissions']); $j++) {
                // Create Permission
                $permission = Permission::create(['name' => $permissions[$i]['permissions'][$j], 'group_name' => $permissionGroup]);
                $roleSuperAdmin->givePermissionTo($permission);
                $permission->assignRole($roleSuperAdmin);
            }
        }
    }
}
