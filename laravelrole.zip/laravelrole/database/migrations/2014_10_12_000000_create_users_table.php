<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->string('titlename')->nullable();
            $table->string('name');
            $table->string('namel');
            $table->string('email')->unique()->nullable();
            $table->string('fname')->nullable();
            $table->integer('fno')->nullable();
            $table->string('mname')->nullable();
            $table->integer('mno')->nullable();
            $table->string('gendername')->nullable();
            $table->string('systemtype')->nullable();
            $table->string('eid')->unique();
            $table->integer('nid')->unique()->nullable();
            $table->date('start')->nullable();
            $table->date('end')->nullable();
            $table->date('bd')->nullable();
            $table->string('place')->nullable();
            $table->string('maritalstatus')->nullable();
            $table->string('nationalityname')->nullable();
            $table->mediumText('image')->nullable();
            $table->string('office')->nullable();
            $table->string('address')->nullable();
            $table->integer('ono')->nullable();
            $table->integer('pno')->nullable();
            $table->string('shortname')->nullable();
            $table->string('statusassign')->nullable();
            $table->string('jobname')->nullable();
            $table->integer('sscale')->nullable();
            $table->string('gradecode')->nullable();
            $table->string('locationcode')->nullable();
            $table->string('supname')->nullable();
            $table->integer('supno')->nullable();
            $table->string('assignno')->nullable();
            $table->string('period')->nullable();
            $table->string('categoryname')->nullable();
            $table->string('periodend')->nullable();
            $table->string('grp')->nullable();
            $table->string('notice')->nullable();
            $table->string('positionname')->nullable();
            $table->string('whour')->nullable();
            $table->string('shr')->nullable();
            $table->time('stime')->nullable();
            $table->time('etime')->nullable();
            $table->string('checkbox')->nullable();
            $table->date('datestart')->nullable();
            $table->date('dateend')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
