<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('items', function (Blueprint $table) {
            $table->id();
            $table->invcode();
            $table->invname();
            $table->itemcode()->unique();
            $table->itemdes();
            $table->measure();
            $table->itemtype();
            $table->itemstatus();
            $table->lot();
            $table->makebuy();
            $table->minitem();
            $table->maxitem();
            $table->mindays();
            $table->maxdays();
            $table->invitem();
            $table->stockable();
            $table->reservable();
            $table->transactable();
            $table->purchaseable();
            $table->customerordered();
            $table->internalordered();
            $table->shippabbleordered();
            $table->returnable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('items');
    }
}
