<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInventoryorgsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('inventoryorgs', function (Blueprint $table) {
            $table->id();
            $table->istart();
            $table->iend();
            $table->lname();
            $table->ladd();
            $table->invcode();
            $table->invname();
            $table->ledgername();
            $table->legalname();
            $table->shortname();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('inventoryorgs');
    }
}
